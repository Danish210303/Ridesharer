#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
print("Content-Type: text/html\r\n\r\n")

import cgi, cgitb, pymysql, os
cgitb.enable()

con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()
form = cgi.FieldStorage()
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RideShare - Connect & Travel Together</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" />
    <link rel="stylesheet" href="static/style.css">

    <style>
        body {
            background: linear-gradient(135deg, #1355e3, #032337, #3cc5ff);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

        .form-sec {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(8px);
            padding: 30px;
            border-radius: 16px;
            width: 600px;
            max-width: 100%;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.25);
        }

        h2 {
            color: white;
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            font-weight: bold;
        }

        .form-label,
        .form-check-label {
            color: white;
            font-size: 16px;
        }

        .form-control,
        .form-select {
            background-color: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 10px;
            height: 42px;
            font-size: 15px;
        }

        .form-control:focus,
        .form-select:focus {
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.4);
            outline: none;
        }

        .btn-light {
            height: 45px;
            font-weight: bold;
            font-size: 16px;
            border-radius: 10px;
            text-decoration: none;
        }

        .register-link {
            display: block;
            margin-top: 15px;
            text-align: center;
            color: white;
        }
        
        .forgot-password {
            display: block;
            text-align: right;
            margin-bottom: 15px;
            color: white;
            text-decoration: none;
        }
        
        .forgot-password:hover {
            text-decoration: underline;
            color: #ddd;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#" style="color: rgba(14, 93, 230, 0.963);"><i
                        class="bi bi-car-front-fill"></i> Ride Sharer</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" href="main.html" style="color: rgba(14, 93, 230, 0.963);">Home</a>
                        <a class="nav-link" href="about.html" style="color: rgba(14, 93, 230, 0.963);">About</a>
                        <a class="nav-link" href="how_it_works.html" style="color: rgba(14, 93, 230, 0.963);">How it
                            Works</a>
                        <a class="nav-link" href="contact.html" style="color: rgba(14, 93, 230, 0.963);">Contact</a>
                    </div>

                    <div class="dropdown ms-auto me-2">
                        <button class="btn btn-outline dropdown-toggle login" type="button" id="dropdownMenuButton1"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Login
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li><a class="dropdown-item" href="login_admin.py">Admin Login</a></li>
                            <li><a class="dropdown-item" href="ridesharer_login.py">Sharer Login</a></li>
                            <li><a class="dropdown-item" href="rideseeker_loginpage.py">Seeker Login</a></li>
                        </ul>
                    </div>

                    <div class="dropdown">
                        <button class="btn btn-outline dropdown-toggle register" type="button" id="dropdownMenuButton2"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Register
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
                            <li><a class="dropdown-item" href="ridesharer.py">Ride Sharer</a></li>
                            <li><a class="dropdown-item" href="ride_seeker.py">Ride Seeker</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Ride Seeker Login Form -->
    <section class="form-sec">
        <div class="form-container">
            <h2>Ride Sharer Login</h2>
            <form method="post"  enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" class="form-control" id="user" name="user" placeholder="Enter username"
                        required />
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter password"
                        required />
                    <a href="forgot_password.py" class="forgot-password">Forgot Password?</a>
                </div>

                <div class="d-flex justify-content-between">
                    <a href="main.html" class="btn btn-light">Cancel</a>
                    <button type="submit" name="login" class="btn btn-light">Login</button>
                </div>

                <a href="ridesharer.py" class="register-link">Create a new Register</a>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>RideShare</h3>
                    <p>Making travel affordable, efficient, and sustainable through shared rides.</p>
                    <div class="social-links">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>

                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="main.html">Home</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="how_it_works.html">How It Works</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links">
                        <li><a href="#">Daily Commute</a></li>
                        <li><a href="#">Long Distance</a></li>
                        <li><a href="#">Event Rides</a></li>
                        <li><a href="#">Airport Transfers</a></li>
                        <li><a href="#">Business Travel</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Download App</h3>
                    <p>Get the best experience with our mobile app</p>
                    <a href="#" class="d-flex align-items-center mb-2 text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-apple fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">Download on the</div>
                            <div style="font-weight: 500;">App Store</div>
                        </div>
                    </a>
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-google-play fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">GET IT ON</div>
                            <div style="font-weight: 500;">Google Play</div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="footer-bottom text-center py-3">
                <p class="mb-0">&copy; 2025 RideShare. All rights reserved.</p>
            </div>
        </div>
    </footer>

</body>

</html>""")

user = form.getvalue("user")
password = form.getvalue("password")
login = form.getvalue("login")

if login is not None:
    data = f"""select id from register_sharer where username='{user}' AND password='{password}' """
    cur.execute(data)
    con.commit()
    da = cur.fetchone()
    if da:
        print(f"""<script> alert('Login Successfully'); location.href='ridesharer_dashboard.py?id={da[0]}';</script>""")
    else:
        print(f"""<script> alert('user not found');location.href='ridesharer_login.py'; </script>""")
con.close()
