#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
print("Content-Type: text/html\r\n\r\n")

import cgi, cgitb, pymysql, os,hashlib
from datetime import datetime
cgitb.enable()

con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()
form = cgi.FieldStorage()

print("""
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Ride Seeker Registration</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="static/style.css">
  <style>
    body {
      background: linear-gradient(135deg, #1355e3, #032337, #3cc5ff);
      min-height: 100vh;
      margin: 0;
      color: white;
    }
    .main-wrapper {
      margin-top:90px;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: calc(100vh - 70px);
    }
    .form-container {
      background: rgba(255, 255, 255, 0.2);
      backdrop-filter: blur(8px);
      padding: 30px;
      border-radius: 16px;
      width: 600px;
    }
    .form-control, .form-select {
      background: rgba(255, 255, 255, 0.8);
      border-radius: 10px;
      border: none;
    }
    
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light py-3 shadow-sm sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="#" style="color: #1355e3;"><i class="bi bi-car-front-fill"></i> Ride Sharer</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup"
      aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" href="main.html" style="color: #1355e3;">Home</a>
        <a class="nav-link" href="about.html" style="color: #1355e3;">About</a>
        <a class="nav-link" href="how_it_works.html" style="color: #1355e3;">How it Works</a>
        <a class="nav-link" href="contact.html" style="color: #1355e3;">Contact</a>
      </div>

      <div class="dropdown ms-auto me-2">
        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">Login</button>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="admin_user.py">Admin Login</a></li>
          <li><a class="dropdown-item" href="ridesharer_login.py">Sharer Login</a></li>
          <li><a class="dropdown-item" href="rideseeker_loginpage.py">Seeker Login</a></li>
        </ul>
      </div>

      <div class="dropdown">
        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">Register</button>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="ridesharer.py">Ride Sharer</a></li>
          <li><a class="dropdown-item" href="ride_seeker.py">Ride Seeker</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>

<!-- Form Section -->
<div class="main-wrapper">
  <div class="form-container">
    <h2 class="text-center mb-4">Ride Seeker Registration</h2>
    <form method="post" enctype="multipart/form-data" onsubmit="return validateForm();">
      <div class="mb-3"><label class="form-label">Name</label><input type="text" class="form-control" name="name"/></div>
      <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" name="email"/></div>
      <div class="mb-3"><label class="form-label">Phone</label><input type="text" class="form-control" name="phone"/></div>
      <div class="mb-3"><label class="form-label">DOB</label><input type="date" class="form-control" name="dob"/></div>
      <div class="mb-3"><label class="form-label">Gender</label>
        <select name="gender" class="form-select">
          <option selected disabled value="">--Select Gender--</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div class="mb-3"><label class="form-label">Aadhaar</label><input type="file" class="form-control" name="aadhaar"/></div>
      <div class="mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
      <div class="mb-3"><label class="form-label">Country</label><select class="form-select" name="country" id="country" onchange="loadStates()"><option selected disabled>--Select--</option></select></div>
      <div class="mb-3"><label class="form-label">State</label><select class="form-select" name="state" id="state" onchange="loadCities()"><option selected disabled>--Select--</option></select></div>
      <div class="mb-3"><label class="form-label">City</label><select class="form-select" name="city" id="city"><option selected disabled>--Select--</option></select></div>
      <div class="mb-3"><label class="form-label">Pincode</label><input type="text" class="form-control" name="pincode"/></div>
      <div class="mb-3"><label class="form-label">Username</label><input type="text" class="form-control" name="username"/></div>
      <div class="mb-3"><label class="form-label">Password</label><input type="password" class="form-control" name="password"/></div>
      <div class="mb-3"><label class="form-label">Confirm Password</label><input type="password" class="form-control" name="confirm_password"/></div>
      <div class="text-center"><button type="submit" name="register" class="btn btn-info">Register</button></div>
    </form>
  </div>
</div>
   <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>RideShare</h3>
                    <p>Making travel affordable, efficient, and sustainable through shared rides.</p>
                    <div class="social-links">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>

                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="main.py" target="_self">Home</a></li>
                        <li><a href="about.py" target="_self">About Us</a></li>
                        <li><a href="how_it_works.py" target="_self">How It Works</a></li>
                        <li><a href="contact.py" target="_self">Contact Us</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links">
                        <li><a href="#">Daily Commute</a></li>
                        <li><a href="#">Long Distance</a></li>
                        <li><a href="#">Event Rides</a></li>
                        <li><a href="#">Airport Transfers</a></li>
                        <li><a href="#">Business Travel</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Download App</h3>
                    <p>Get the best experience with our mobile app</p>
                    <a href="#" class="d-flex align-items-center mb-2 text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-apple fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">Download on the</div>
                            <div style="font-weight: 500;">App Store</div>
                        </div>
                    </a>
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-google-play fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">GET IT ON</div>
                            <div style="font-weight: 500;">Google Play</div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="footer-bottom text-center py-3">
                <p class="mb-0">&copy; 2025 RideShare. All rights reserved.</p>
            </div>
        </div>
    </footer>


<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Location + Validation Scripts -->
<script>
const locationData = {
  "India": {
    "Tamil Nadu": ["Chennai", "Coimbatore"],
    "Maharashtra": ["Mumbai", "Pune"]
  },
  "USA": {
    "California": ["Los Angeles", "San Francisco"],
    "Texas": ["Houston", "Dallas"]
  }
};

window.onload = () => {
  const countrySelect = document.getElementById("country");
  for (const country in locationData) {
    const option = document.createElement("option");
    option.value = country;
    option.text = country;
    countrySelect.appendChild(option);
  }
};

function loadStates() {
  const country = document.getElementById("country").value;
  const stateSelect = document.getElementById("state");
  const citySelect = document.getElementById("city");
  stateSelect.innerHTML = '<option disabled selected>--Select--</option>';
  citySelect.innerHTML = '<option disabled selected>--Select--</option>';
  for (const state in locationData[country]) {
    const option = document.createElement("option");
    option.value = state;
    option.text = state;
    stateSelect.appendChild(option);
  }
}

function loadCities() {
  const country = document.getElementById("country").value;
  const state = document.getElementById("state").value;
  const citySelect = document.getElementById("city");
  citySelect.innerHTML = '<option disabled selected>--Select--</option>';
  locationData[country][state].forEach(city => {
    const option = document.createElement("option");
    option.value = city;
    option.text = city;
    citySelect.appendChild(option);
  });
}

function validateForm() {
  const f = document.forms[0];
  if (!f.name.value.trim()) return alert("Name is required."), false;
  if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(f.email.value)) return alert("Enter a valid email."), false;
  if (!/^[0-9]{10}$/.test(f.phone.value)) return alert("Phone must be 10 digits."), false;
  if (!f.gender.value) return alert("Please select a gender."), false;
  if (!f.aadhaar.value) return alert("Aadhaar is required."), false;
  if (!f.address.value.trim()) return alert("Address is required."), false;
  if (!f.country.value) return alert("Please select a country."), false;
  if (!f.state.value) return alert("Please select a state."), false;
  if (!f.city.value) return alert("Please select a city."), false;
  if (!/^[0-9]{6}$/.test(f.pincode.value)) return alert("Pincode must be 6 digits."), false;
  if (!f.username.value.trim()) return alert("Username is required."), false;
  if (f.password.value.length < 6) return alert("Password must be at least 6 characters."), false;
  if (f.password.value !== f.confirm_password.value) return alert("Passwords do not match."), false;
  return true;
}
</script>

</body>
</html>
""")

# ==================== Back-End ====================
if "register" in form:
    try:
        name = form.getvalue("name")
        email = form.getvalue("email")
        phone = form.getvalue("phone")
        dob = form.getvalue("dob")
        date1 = datetime.strptime(dob, "%Y-%m-%d")
        date2 = date1.strftime("%d-%m-%Y")
        gender = form.getvalue("gender")
        address = form.getvalue("address")
        aadhaar = form["aadhaar"]
        country = form.getvalue("country")
        state = form.getvalue("state")
        city = form.getvalue("city")
        pincode = form.getvalue("pincode")
        username = form.getvalue("username")
        password = form.getvalue("password")

        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        # Save Aadhaar file
        if not os.path.exists("database"):
            os.makedirs("database")
        aadhaar_file = os.path.basename(aadhaar.filename)
        aadhaar_path = os.path.join("database", aadhaar_file)
        with open(aadhaar_path, "wb") as f:
            f.write(aadhaar.file.read())

        # DB Insert
        con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
        cur = con.cursor()
        sql = """INSERT INTO register_seeker 
        (name, email, phone, dob, gender, aadhar, address, country, state, city, pincode, user_name, user_password)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        cur.execute(sql, (name, email, phone, date2, gender, aadhaar_file, address, country, state, city, pincode, username, hashed_password))
        con.commit()
        con.close()
        print("<script>alert('Registration Successful!');location.href='rideseeker_loginpage.py';</script>")
    except Exception as e:
        print(f"<script>alert('Error: {str(e)}');</script>")
