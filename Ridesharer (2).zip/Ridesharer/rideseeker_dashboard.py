#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html; charset=utf-8\r\n\r\n")

import cgi, cgitb, pymysql
cgitb.enable()

# Database connection
try:
    con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
    cur = con.cursor()

    form = cgi.FieldStorage()
    user = form.getvalue('id')

    if not user:
        raise ValueError("User ID is required")

    cur.execute("SELECT * FROM register_seeker WHERE id = %s", (user,))
    user_data = cur.fetchone()

    if not user_data:
        raise ValueError("User not found")

    user_name = user_data[1] if user_data else "Seeker User"
    image_path = f"database/{user_data[14]}" if user_data and user_data[14] else "https://i.ibb.co/4f3J9Cx/avatar.png"

except Exception as e:
    print(f"<script>alert('Error: {str(e)}'); window.location.href='main.html';</script>")
    sys.exit()

# HTML Template
print(f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>RideShare Connect | Seeker Dashboard</title>

<!-- Bootstrap CSS + Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

<style>
:root {{
    --primary-color: #4361ee;
    --header-height: 80px;
    --sidebar-width: 300px;
}}

body {{
    padding-top: var(--header-height);
    background-color: #f8f9fa;
    margin: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}}

/* FIXED HEADER */
.admin-header {{
    background: linear-gradient(135deg, #0449de, #1d5c9b);
    color: white;
    padding: 0 20px;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    height: var(--header-height);
    display: flex;
    align-items: center;
    justify-content: space-between;
}}

.logo {{
    display: flex;
    align-items: center;
    gap: 15px;
}}

.logo i {{
    font-size: 25px;
}}

.logo h1 {{
    font-size: 18px;
    font-weight: 600;
    margin: 0;
}}

.sidebar {{
    background: white;
    height: calc(100vh - var(--header-height));
    overflow-y: auto;
    padding: 25px 0;
    position: fixed;
    top: var(--header-height);
    width: var(--sidebar-width);
    left: calc(-1 * var(--sidebar-width));
    transition: all 0.3s ease;
    z-index: 999;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}}

.sidebar.show {{
    left: 0;
}}

.overlay {{
    position: fixed;
    top: var(--header-height);
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 998;
    display: none;
}}

.overlay.show {{
    display: block;
}}

.sidebar-header {{
    padding: 20px 25px;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    align-items: center;
}}

.sidebar-header img {{
    width: 50px;
    height: 50px;
    border-radius: 50%;
    object-fit: cover;
    background: #e9ecef;
}}

.user-info h3 {{
    font-size: 20px;
    margin-bottom: 5px;
}}

.user-info p {{
    color: #3f37c9;
    font-size: 15px;
    margin: 0;
}}

.sidebar-menu {{
    padding: 20px 0;
}}

.menu-item {{
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 12px 25px;
    color: #212529;
    text-decoration: none;
    transition: all 0.3s ease;
    font-weight: 500;
}}

.menu-item:hover,
.menu-item.active {{
    background: #4361ee;
    color: white;
}}

.menu-item i {{
    font-size: 20px;
}}

.dropdown-menu {{
    background-color: #fff;
    border-radius: 8px;
    padding: 0;
    border: 1px solid #ddd;
    margin-left: 20px;
}}

.dropdown-item {{
    padding: 10px 20px;
    color: #333;
    font-size: 14px;
}}

.dropdown-item:hover {{
    background-color: #f0f0f0;
    color: #000;
}}

.content-wrapper {{
    margin-left: 0;
    padding: 30px 15px;
    min-height: calc(100vh - var(--header-height));
    transition: all 0.3s ease;
}}

.profile-card {{
    background-color: #fff;
    border-radius: 12px;
    padding: 30px 20px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    max-width: 600px;
    margin: 0 auto;
}}

.menu-toggle {{
    display: block;
    background: none;
    border: none;
    color: white;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 5px;
}}

@media (min-width: 992px) {{
    .sidebar {{
        left: 0;
    }}
    .content-wrapper {{
        margin-left: var(--sidebar-width);
        padding: 30px;
    }}
    .menu-toggle {{
        display: none;
    }}
    .overlay {{
        display: none !important;
    }}
}}

@media (max-width: 576px) {{
    .admin-header {{
        padding: 0 10px;
    }}
    .sidebar {{
        width: 280px;
    }}
    .profile-card {{
        padding: 20px 15px;
    }}
}}
</style>
</head>

<body>

 <!-- Header -->
  <div class="admin-header">
    <div class="container">
      <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
          <button class="menu-toggle me-3 d-lg-none" type="button" onclick="toggleSidebar()">
            <i class="bi bi-list"></i>
          </button>
         <div class="logo d-flex align-items-center">
        <i class="bi bi-car-front-fill me-2"></i>
        <h1 class="mb-0 fs-5">Ride Seeker Dashboard</h1>
      </div>
        </div>
        <div class="d-flex align-items-center">
          <div class="me-3 text-end d-none d-md-block">
            <h5 class="mb-0">{user_name}</h5>
            <small>Ride Seeker</small>
          </div>
          <img src="{image_path}" class="rounded-circle" width="50" alt="profile">
        </div>
      </div>
    </div>
  </div>

  <!-- Sidebar Overlay -->
  <div class="overlay" onclick="toggleSidebar()"></div>

  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <img src="{image_path}" width="50" class="rounded-circle" alt="profile">
      <div class="user-info ms-3">
        <h3>{user_name}</h3>
        <p>Ride Seeker</p>
      </div>
    </div>
    <div class="sidebar-menu">
      <a href="./rideseeker_profile.py?id={user}" class="menu-item">
        <i class="bi bi-person-square"></i> Profile
      </a>
      <a href="./rideseeker_search.py?id={user}" class="menu-item">
        <i class="bi bi-search"></i> Search Rides
      </a>
      <div class="dropdown">
        <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
          <i class="bi bi-journal-text"></i> My Booking
        </a>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="./rideseeker_bookingpending.py?id={user}">Requested</a></li>
          <li><a class="dropdown-item" href="./rideseeker_bookingcompleted.py?id={user}">Confirmed</a></li>
          <li><a class="dropdown-item" href="./rideseeker_bookingcancel.py?id={user}">Cancel</a></li>
          <li><a class="dropdown-item" href="./rideseeker_bookinghistory.py?id={user}">Booking History</a></li>
        </ul>
      </div>
      <a href="main.py?user_id={user}" class="menu-item logout">
        <i class="bi bi-arrow-left-circle"></i> Logout
      </a>
    </div>
  </div>


<main class="content-wrapper" id="contentWrapper">
    <div class="container">
        <div class="profile-card text-center">
            <div class="card-body py-4">
                <h4 class="card-title">Welcome <span class="text-primary">{user_name}</span></h4>
                <p class="card-text mt-3">You can manage your ride bookings and profile from this dashboard.</p>
            </div>
        </div>
    </div>
</main>

<script>
function toggleSidebar() {{
    const sidebar = document.getElementById('sidebar');
    const overlay = document.querySelector('.overlay');
    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');
}}

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {{
    const sidebar = document.getElementById('sidebar');
    const overlay = document.querySelector('.overlay');
    const menuToggle = document.querySelector('.menu-toggle');
    
    if (window.innerWidth < 992) {{
        const isClickInsideSidebar = sidebar.contains(event.target);
        const isClickOnMenuToggle = event.target === menuToggle || menuToggle.contains(event.target);
        
        if (!isClickInsideSidebar && !isClickOnMenuToggle && sidebar.classList.contains('show')) {{
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        }}
    }}
}});

// Close sidebar when resizing to desktop
window.addEventListener('resize', function() {{
    const sidebar = document.getElementById('sidebar');
    const overlay = document.querySelector('.overlay');
    
    if (window.innerWidth >= 992) {{
        sidebar.classList.remove('show');
        overlay.classList.remove('show');
    }}
}});
</script>

</body>
</html>
""")

if 'con' in locals():
    con.close()
