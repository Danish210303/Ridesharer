#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
print("content-type:text/html \r\n\r\n")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideShare - Connect & Travel Together</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="static/style.css">
    <style>
        .hero {
            padding: 5rem 5% 3rem;
            text-align: center;
            background-color: rgba(26, 42, 108, 0.8);
            color: white;
            position: relative;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(7, 134, 225, 0.9) 0%, rgba(40, 174, 197, 0.7) 100%);
        }

        .hero-content {
            position: relative;
            max-width: 900px;
            margin: 0 auto;
            padding: 2rem;
        }

        .hero h1 {
            font-size: 3.5rem;
            margin-bottom: 1rem;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        .hero p {
            font-size: 1.3rem;
            max-width: 700px;
            margin: 0 auto 2rem;
            line-height: 1.7;
        }

        .cta-button {
            background: #ffcc00;
            color: #1a2a6c;
            padding: 10px 25px;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }

        .cta-button:hover {
            background: #eddb11;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#" style="color: rgba(14, 93, 230, 0.963);"><i class="bi bi-car-front-fill"></i> Ride Sharer</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" style="color: rgba(14, 93, 230, 0.963);" href="main.py">Home</a>
                        <a class="nav-link" style="color: rgba(14, 93, 230, 0.963);" href="about.py">About</a>
                        <a class="nav-link" style="color: rgba(14, 93, 230, 0.963);" href="how_it_works.py">How it
                            Works</a>
                        <a class="nav-link" style="color: rgba(14, 93, 230, 0.963);" href="contact.py">Contact</a>
                    </div>

                    <div class="dropdown ms-auto me-2">
                        <button class="btn btn-outline dropdown-toggle login" type="button" id="dropdownMenuButton1"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Login
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li><a class="dropdown-item" href="login_admin.py">Admin Login</a></li>
                            <li><a class="dropdown-item" href="ridesharer_login.py">Sharer Login</a></li>
                            <li><a class="dropdown-item" href="rideseeker_loginpage.py">Seeker Login</a></li>
                        </ul>
                    </div>

                    <div class="dropdown">
                        <button class="btn btn-outline dropdown-toggle register" type="button" id="dropdownMenuButton2"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Register
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
                            <li><a class="dropdown-item" href="ridesharer.py">Ride Sharer</a></li>
                            <li><a class="dropdown-item" href="ride_seeker.py">Ride Seeker</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>



    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>How Ride Sharer Works</h1>
            <p>Discover the simple steps to request a ride or become a driver. Our platform makes transportation easy,
                reliable, and affordable for everyone.</p>
            <a href="#" class="cta-button">Get Started Today</a>
        </div>
    </section>
    <!-- Users -->
    <section class="py-5">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="section-title">How to Request a Ride</h2>

                    </p>
                </div>
            </div>

            <div class="row mt-5 g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-geo-alt-fill"></i>
                        </div>
                        <h4>Set Your Location</h4>
                        <p class="text-muted">Open the app and allow location access, or enter your pickup address
                            manually. You can also save favorite locations for quick access.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-flag-fill"></i>
                        </div>
                        <h4>Enter Destination</h4>
                        <p class="text-muted">Type in where you want to go. See the estimated fare and arrival time
                            before confirming your ride.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-car-front-fill"></i>
                        </div>
                        <h4>Choose Your Ride</h4>
                        <p class="text-muted">Select from various options - Solo, Group, Premium, or Eco-friendly. See
                            driver details and car information.
                        </p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-credit-card"></i>
                        </div>
                        <h4>Payment & Ride</h4>
                        <p class="text-muted">Pay securely through the app. Track your driver in real-time. Rate your
                            experience after the ride.


                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Driver -->
    <section class="py-5">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="section-title">How to Become a Driver</h2>

                    </p>
                </div>
            </div>

            <div class="row mt-5 g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-person-vcard-fill"></i>
                        </div>
                        <h4>
                            Apply Online</h4>
                        <p class="text-muted">Complete our simple online application. Provide required documents
                            including driver's license and vehicle registration..</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-car-front-fill"></i>
                        </div>
                        <h4>Vehicle Check</h4>
                        <p class="text-muted">Ensure your vehicle meets our safety standards. Most 4-door cars 10 years
                            or newer qualify for our service.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-shield-shaded"></i>
                        </div>
                        <h4>Background Check</h4>
                        <p class="text-muted">We conduct a thorough background screening to ensure safety for our
                            community. This typically takes 3-5 business days.
                        </p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-align-start"></i>
                        </div>
                        <h4>Start Driving</h4>
                        <p class="text-muted">Once approved, go online when you're ready to drive. Set your schedule and
                            start earning money immediately

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div class="stat-number">500K+</div>
                <div class="stat-text">Happy Users</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-geo-alt-fill"></i>
                </div>
                <div class="stat-number">120+</div>
                <div class="stat-text">Cities Covered</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-car-front-fill"></i>
                </div>
                <div class="stat-number">1M+</div>
                <div class="stat-text">Rides Shared</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-tree-fill"></i>
                </div>
                <div class="stat-number">250K+</div>
                <div class="stat-text">CO2 Saved (tons)</div>
            </div>
        </div>
    </section>


    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>RideShare</h3>
                    <p style="margin-bottom: 20px; color:gray;">Making travel affordable, efficient, and sustainable
                        through shared rides.</p>
                    <div class="social-links">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>

                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                         <li><a href="main.py" target="_self">Home</a></li>
                        <li><a href="about.py" target="_self">About Us</a></li>
                        <li><a href="how_it_works.py" target="_self">How It Works</a></li>
                        <li><a href="contact.py" target="_self">Contact Us</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links">
                        <li><a href="#">Daily Commute</a></li>
                        <li><a href="#">Long Distance</a></li>
                        <li><a href="#">Event Rides</a></li>
                        <li><a href="#">Airport Transfers</a></li>
                        <li><a href="#">Business Travel</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Download App</h3>
                    <p style="margin-bottom: 15px; color: #cccccc;">Get the best experience with our mobile app</p>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <a href="#"
                            style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; color: white; text-decoration: none; transition: all 0.3s;">
                            <i class="bi bi-apple" style="font-size: 1.5rem;"></i>
                            <div>
                                <div style="font-size: 0.8rem;">Download on the</div>
                                <div style="font-weight: 500;">App Store</div>
                            </div>
                        </a>
                        <a href="#"
                            style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; color: white; text-decoration: none; transition: all 0.3s;">
                            <i class="bi bi-google-play" style="font-size: 1.5rem;"></i>
                            <div>
                                <div style="font-size: 0.8rem;">GET IT ON</div>
                                <div style="font-weight: 500;">Google Play</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 RideShare. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>

</html>""")
