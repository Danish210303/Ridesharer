#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import os
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html\r\n\r\n")

import cgi, cgitb, pymysql
cgitb.enable()

# Get form data
form = cgi.FieldStorage()
d = form.getvalue('id')

# DB connection
con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()

# Fetch user data using the passed ID
cur.execute("SELECT * FROM register_sharer WHERE id=%s", (d,))
row = cur.fetchone()

# HTML Starts
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RideShare Connect | Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }

    .admin-header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        background: linear-gradient(135deg, #0449de, #1d5c9b);
        color: white;
        padding: 15px 20px;
        z-index: 1000;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
      .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo i {
            font-size: 25px;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
        }

        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 80px;
            left: 0;
            width: 300px;
            height: calc(100vh - 80px);
            background: white;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 999;
        }

        .sidebar.collapsed {
            left: -300px;
        }

        /* Sidebar Sections */
        .sidebar-header {
            padding: 20px 25px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            align-items: center;
        }

        .sidebar-header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }

        .user-info h3 {
            font-size: 20px;
            margin: 0 0 3px 0;
        }

        .user-info p {
            color: #3f37c9;
            margin: 0;
            font-size: 15px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 25px;
            color: #212529;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: #4361ee;
            color: white;
            border-left: 3px solid white;
        }

        .menu-item i {
            font-size: 20px;
        }

        /* Logout button spacing */
        .logout {
            margin-top: 30px;
        }

        /* Main Content */
        .main-content {
            margin-left: 300px;
            padding: 100px 20px 20px;
            transition: all 0.3s ease;
        }

        .main-content.expanded {
            margin-left: 0;
        }

        /* Profile Card */
        .profile-card {
            background-color: #fff;
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            max-width: 600px;
            margin: 0 auto;
            text-align: center;
        }

        .profile-pic {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 20px;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .profile-pic:hover {
            transform: scale(1.05);
        }

        /* Mobile Menu Button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
        }

        /* Responsive Adjustments */
        @media (max-width: 991px) {
            .sidebar {
                margin-top:-30px;
                left: -300px;
            }
            
            .sidebar.show {
                left: 0;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            .profile-card {
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            .profile-pic {
                width: 100px;
                height: 100px;
            }
            
            .logo h1 {
                font-size: 18px;
            }
            
            .admin-header {
                padding: 10px 15px;
            }
            
            .profile-card {
                padding: 15px;
            }
        }

        /* Dropdown menu styles */
        .dropdown-menu {
            border: none;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        .dropdown-item {
            padding: 8px 20px;
        }
        
        .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #4361ee;
        }
    </style>
</head>
<body>
""")

# If user exists
if row:
    image_path = f"database/{row[8]}" if row[8] else "https://i.ibb.co/4f3J9Cx/avatar.png"

    print(f"""
    <!-- Header -->
    <div class="admin-header">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <button class="mobile-menu-btn me-3" id="mobileMenuBtn">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="logo">
                        <i class="bi bi-car-front-fill"></i>
                        <h1>Ride Sharer Dashboard</h1>
                    </div>
                </div>
                <div class="d-flex align-items-center">
                    <div class="me-3 text-end d-none d-md-block">
                        <h5 class="mb-0">{row[1]}</h5>
                        <small>Ride Sharer</small>
                    </div>
                    <img src="{image_path}" class="rounded-circle" width="50" alt="profile" />
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="{image_path}" class="rounded-circle" width="50" alt="profile">
            <div class="user-info ms-3">
                <h3>{row[1]}</h3>
                <p>Ride Sharer</p>
            </div>
        </div>
        <div class="sidebar-menu">
            <a href="ridesharer_profile.py?id={d}" class="menu-item active"><i class="bi bi-person-square"></i> Profile</a>
            
            <div class="dropdown">
                <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="bi bi-car-front-fill"></i> My Rides
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="ridesharer_postride.py?id={d}">Post Ride</a></li>
                    <li><a class="dropdown-item" href="ridesharer_viewride.py?id={d}">View Ride</a></li>
                </ul>
            </div>
            
            <div class="dropdown">
                <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="bi bi-journal-text"></i> Booking Request
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="ridesharer_requested.py?id={d}">Requested</a></li>
                    <li><a class="dropdown-item" href="ridesharer_confirmed.py?id={d}">Confirm</a></li>
                    <li><a class="dropdown-item" href="ridesharer_cancel.py?id={d}">Cancel</a></li>
                    <li><a class="dropdown-item" href="ridesharer_history.py?id={d}">Booking History</a></li>
                </ul>
            </div>
            
            <a href="main.py?sharer_id={d}" class="menu-item logout">
                <i class="bi bi-arrow-left-circle"></i> Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="profile-card">
                        <h3 class="mb-4">{row[1]}</h3>
                        <form method="post" enctype="multipart/form-data">
                            <label for="profilePictureInput">
                                <img src="{image_path}" alt="Profile Picture" class="profile-pic">
                            </label>
                            <input type="file" name="change_photo" id="profilePictureInput" style="display:none;" onchange="this.form.submit()">
                        </form>
                        <div class="profile-info mt-4">
                            <p class="mb-3"><strong>Email:</strong> {row[2]}</p>
                            <p class="mb-3"><strong>Phone:</strong> {row[3]}</p>
                            
                            <button type="button" class="btn btn-info mt-3" data-bs-toggle="modal" data-bs-target="#profileModal">
                                Update Profile
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Profile Update Modal -->
    <div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="profileModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="profileModalLabel">Update Profile</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="{row[2]}">
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="phone" name="phone" value="{row[3]}">
                        </div>
                        <input type="hidden" name="id_a" value="{row[0]}">
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <input type="submit" class="btn btn-primary" name="submit" value="Save Changes">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>""")
    print("""

    <script>
        // Mobile menu toggle functionality
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            if (window.innerWidth <= 991 && 
                !sidebar.contains(event.target) && 
                event.target !== mobileMenuBtn && 
                !mobileMenuBtn.contains(event.target)) {
                sidebar.classList.remove('show');
            }
        });
    </script>
""")
else:
    print("""
    <div class="container">
        <div class="alert alert-danger text-center mt-5">
            <h4>No user found with the given ID.</h4>
        </div>
    </div>
""")

# Close HTML
print("""
</body>
</html>
""")

submit = form.getvalue("submit")

# Handle Update Submission First
if submit is not None:
    user_id = form.getvalue('id_a')
    email = form.getvalue('email')
    phone = form.getvalue('phone')

    query = "UPDATE register_sharer SET email=%s, phone=%s WHERE id=%s"
    cur.execute(query, (email, phone, user_id))
    con.commit()

    print(f"""<script>alert("Updated Successfully");location.href='ridesharer_profile.py?id={user_id}';</script>""")

if 'change_photo' in form:
    pht = form['change_photo']
    if pht.filename:
        imgg = os.path.basename(pht.filename)
        open("database/" + imgg, "wb").write(pht.file.read())

        query = "UPDATE register_sharer SET photo=%s WHERE id=%s"
        cur.execute(query, (imgg,d))
        con.commit()

        print(f""" <script>location.href='ridesharer_profile.py?id={d}';</script>""")
    con.close()
