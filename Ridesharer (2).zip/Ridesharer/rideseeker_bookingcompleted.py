#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html; charset=utf-8\r\n\r\n")

import cgi, cgitb, pymysql, os
cgitb.enable()

# DB connection
try:
    con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
    cur = con.cursor()
    form = cgi.FieldStorage()
    user = form.getvalue('id')

    if not user:
        raise ValueError("User ID is required")

    # Fetch user details
    cur.execute("SELECT * FROM register_seeker WHERE id = %s", (user,))
    rows = cur.fetchall()
    if not rows:
        raise ValueError("User not found")

    user_name = rows[0][1]
    image_path = f"database/{rows[0][14]}" if rows[0][14] else "https://i.ibb.co/4f3J9Cx/avatar.png"

    # Fetch canceled bookings for this user only
    query = "SELECT * FROM order_table WHERE seeker_id=%s AND status='Confirm'"
    cur.execute(query, (user,))
    bookings = cur.fetchall()

except Exception as e:
    print(f"<script>alert('Error: {str(e)}'); window.location.href='main.html';</script>")
    sys.exit()

# HTML Start
print(f"""
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>RideShare Connect | Canceled Bookings</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <style>
    :root {{
    --primary-color: #4361ee;
    --header-height: 80px;
    --sidebar-width: 300px;
}}

body {{
    padding-top: var(--header-height);
    background-color: #f8f9fa;
    margin: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}}

/* FIXED HEADER */
.admin-header {{
    background: linear-gradient(135deg, #0449de, #1d5c9b);
    color: white;
    padding: 0 20px;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    height: var(--header-height);
    display: flex;
    align-items: center;
    justify-content: space-between;
}}

.logo {{
    display: flex;
    align-items: center;
    gap: 15px;
}}

.logo i {{
    font-size: 25px;
}}

.logo h1 {{
    font-size: 18px;
    font-weight: 600;
    margin: 0;
}}

    .sidebar {{
      position: fixed;
      top: var(--header-height);
      left: 0;
      width: 300px;
      height: calc(100vh - var(--header-height));
      background-color: white;
      overflow-y: auto;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.05);
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      z-index: 1020;
    }}
    
    .sidebar.show {{
      transform: translateX(0);
    }}
    
    .main-content {{
      padding: 30px;
      transition: margin-left 0.3s ease;
    }}
    
    .menu-toggle {{
      display: none;
      background: none;
      border: none;
      color: white;
      font-size: 1.5rem;
      cursor: pointer;
    }}
    
    .menu-item {{
      display: flex;
      align-items: center;
      gap: 15px;
      padding: 12px 25px;
      color: #212529;
      text-decoration: none;
      transition: all 0.3s ease;
      font-weight: 500;
    }}
    
    .menu-item:hover, .menu-item.active {{
         background: #4361ee;
          color: white;
    }}
    
    .menu-item i {{
      margin-right: 10px;
      font-size: 1.1rem;
    }}
    
    .sidebar-overlay {{
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 1010;
      opacity: 0;
      visibility: hidden;
      transition: all 0.3s ease;
    }}
    
    .sidebar-overlay.show {{
      opacity: 1;
      visibility: visible;
    }}
    
    .booking-table {{
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      overflow: hidden;
    }}
    
    .status-badge {{
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 500;
    }}
    
    .status-canceled {{
      background-color: #ffebee;
      color: #c62828;
    }}
    
    @media (min-width: 992px) {{
      .sidebar {{
        transform: translateX(0);
      }}
      
      .main-content {{
        margin-left: var(--sidebar-width);
      }}
      
      .menu-toggle {{
        display: none;
      }}
      
      .sidebar-overlay {{
        display: none !important;
      }}
    }}
    
    @media (max-width: 991.98px) {{
      .menu-toggle {{
        display: block;
      }}
    }}
    
    @media (max-width: 767.98px) {{
      :root {{
        --header-height: 70px;
      }}
      
      .main-content {{
        padding: 20px 15px;
      }}
      
      .table-responsive {{
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
      }}
    }}
  </style>
</head>
<body>
  <!-- Header -->
  <header class="admin-header d-flex align-items-center justify-content-between">
    <div class="d-flex align-items-center">
      <button class="menu-toggle me-3" id="menuToggle">
        <i class="bi bi-list"></i>
      </button>
      <div class="logo d-flex align-items-center">
        <i class="bi bi-car-front-fill me-2"></i>
        <h1 class="mb-0 fs-5">Ride Seeker Dashboard</h1>
      </div>
    </div>
    <div class="d-flex align-items-center">
      <div class="text-end me-3 d-none d-md-block">
        <h6 class="mb-0">{user_name}</h6>
        <small class="text-white-50">Ride Seeker</small>
      </div>
      <img src="{image_path}" class="rounded-circle" width="40" height="40" alt="profile" style="object-fit: cover;">
    </div>
  </header>

  <!-- Sidebar Overlay -->
  <div class="sidebar-overlay" id="sidebarOverlay"></div>

  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-header d-flex align-items-center p-4 border-bottom">
      <img src="{image_path}" class="rounded-circle me-3" width="50" height="50" alt="profile">
      <div>
        <h5 class="mb-1">{user_name}</h5>
        <small class="text-muted">Ride Seeker</small>
      </div>
    </div>
    <nav class="p-3">
      <a href="./rideseeker_dashboard.py?id={user}" class="menu-item">
        <i class="bi bi-person"></i> Profile
      </a>
      <a href="./rideseeker_search.py?id={user}" class="menu-item">
        <i class="bi bi-search"></i> Search Rides
      </a>
      <div class="dropdown">
        <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
          <i class="bi bi-journal-text"></i> My Booking
        </a>
        <ul class="dropdown-menu active border-0 shadow-sm p-2">
          <li><a class="dropdown-item" href="./rideseeker_bookingpending.py?id={user}">Requested</a></li>
          <li><a class="dropdown-item" href="./rideseeker_bookingcompleted.py?id={user}">Confirmed</a></li>
          <li><a class="dropdown-item active" href="./rideseeker_bookingcancel.py?id={user}">Canceled</a></li>
          <li><a class="dropdown-item" href="./rideseeker_bookinghistory.py?id={user}">History</a></li>
        </ul>
      </div>
      <a href="main.py?user_id={user}" class="menu-item mt-4">
        <i class="bi bi-box-arrow-left"></i> Logout
      </a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="main-content" id="mainContent">
    <div class="container-fluid">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>New Bookings</h3>
        <a href="./rideseeker_search.py?id={user}" class="btn btn-primary">
          <i class="bi bi-plus-circle"></i> Book New Ride
        </a>
      </div>
      
      <div class="booking-table">
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th>Sharer</th>
                <th>Contact</th>
                <th>Pickup</th>
                <th>Drop</th>
                <th>Date</th>
                <th>Time</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
""")

# Loop through bookings
if not bookings:
    print(f"""
              <tr>
                <td colspan="7" class="text-center py-4">
                  <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle me-2"></i> You don't have any New bookings yet.
                  </div>
                </td>
              </tr>
    """)
else:
    for booking in bookings:
        try:
            cur.execute("SELECT name, email, phone FROM register_sharer WHERE id=%s", (booking[14],))
            sharer_data = cur.fetchone()

            if sharer_data:
                print(f"""
              <tr>
                <td>{sharer_data[0]}</td>
                <td>
                  <div>{sharer_data[1]}</div>
                  <small class="text-muted">{sharer_data[2]}</small>
                </td>
                <td>{booking[2]}</td>
                <td>{booking[3]}</td>
                <td>{booking[4]}</td>
                <td>{booking[5]}</td>
                <td><span class="status-badge status-new">{booking[18]}</span></td>
                <td>
    <button type="button" data-bs-toggle="modal" data-bs-target="#modal{booking[0]}" class="btn btn-sm btn-danger">Cancel</button>

    <div class="modal fade" id="modal{booking[0]}" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="post">
            <div class="modal-header">
              <h5 class="modal-title">Cancel Ride</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <input type="hidden" name="id_a" value="{booking[0]}">
              <p>Do you want to Cancel the ride?</p>
            </div>
            <div class="modal-footer">
              <input class="btn btn-success" type="submit" value="Cancel" name="cancel">
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal" aria-label="Close">Close</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </td>
              </tr>
                """)
        except Exception as e:
            print(f"""
              <tr>
                <td colspan="7" class="text-center text-danger">
                  Error loading booking details: {str(e)}
                </td>
              </tr>
            """)

# Closing HTML
print("""
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const menuToggle = document.getElementById('menuToggle');
      const sidebar = document.getElementById('sidebar');
      const sidebarOverlay = document.getElementById('sidebarOverlay');
      const mainContent = document.getElementById('mainContent');
      
      // Toggle sidebar
      menuToggle.addEventListener('click', function() {
        sidebar.classList.toggle('show');
        sidebarOverlay.classList.toggle('show');
      });
      
      // Close sidebar when clicking on overlay
      sidebarOverlay.addEventListener('click', function() {
        sidebar.classList.remove('show');
        sidebarOverlay.classList.remove('show');
      });
      
      // Close sidebar when clicking outside on mobile
      document.addEventListener('click', function(event) {
        if (window.innerWidth <= 991.98) {
          const isClickInsideSidebar = sidebar.contains(event.target);
          const isClickOnMenuToggle = menuToggle.contains(event.target);
          
          if (!isClickInsideSidebar && !isClickOnMenuToggle) {
            sidebar.classList.remove('show');
            sidebarOverlay.classList.remove('show');
          }
        }
      });
      
      // Handle window resize
      window.addEventListener('resize', function() {
        if (window.innerWidth > 991.98) {
          sidebar.classList.remove('show');
          sidebarOverlay.classList.remove('show');
        }
      });
    });
  </script>
</body>
</html>
""")
id_a = form.getvalue('id_a')
cancel = form.getvalue('cancel')
if cancel is not None :
    update_query = "UPDATE order_table SET status='Cancel' WHERE id=%s"
    cur.execute(update_query, (id_a,))
    con.commit()
    con.close()
    print(f"""<script>alert("Ride Canceled"); location.href='rideseeker_bookingpending.py?id={user}';</script>""")

# Close database connection
if 'con' in locals():
    con.close()
