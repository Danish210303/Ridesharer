#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
print("Content-Type: text/html\r\n\r\n")

import cgi, cgitb, pymysql, os, re
from datetime import datetime
cgitb.enable()

con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()
form = cgi.FieldStorage()

# Check if form was submitted
register = form.getvalue('register')

print("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RideShare - Connect & Travel Together</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" />
    <link rel="stylesheet" href="static/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #ffffff, #ffffff, #ffffff);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0; padding: 0;
        }
        .form-sec {
            background: linear-gradient(135deg, #1355e3, #032337, #3cc5ff);
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
            padding: 40px 20px;
        }
        .form-container {
            margin-top:50px;
            background-color: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(8px);
            padding: 30px;
            border-radius: 16px;
            width: 600px;
            max-width: 100%;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.25);
        }
        h2 { color: white; text-align: center; margin-bottom: 20px; font-size: 28px; font-weight: bold; }
        .form-label, .form-check-label { color: white; font-size: 16px; }
        .form-control, .form-select {
            background-color: rgba(255, 255, 255, 0.9);
            border: none; border-radius: 10px; height: 42px; font-size: 15px;
        }
        .form-control:focus, .form-select:focus {
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.4); outline: none;
        }
        .btn-light {
            width: 100%; height: 45px;
            font-weight: bold; font-size: 16px;
            border-radius: 10px;
        }
        .error-box {
            display: none;
            background-color: rgba(255, 0, 0, 0.1);
            color: red;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 8px;
        }
        .success-box {
            display: none;
            background-color: rgba(0, 255, 0, 0.1);
            color: green;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 8px;
        }
    </style>
</head>

<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light py-3 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="#" style="color: #1355e3;"><i class="bi bi-car-front-fill"></i> Ride Sharer</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup"
      aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" href="main.html" style="color: #1355e3;">Home</a>
        <a class="nav-link" href="about.html" style="color: #1355e3;">About</a>
        <a class="nav-link" href="how_it_works.html" style="color: #1355e3;">How it Works</a>
        <a class="nav-link" href="contact.html" style="color: #1355e3;">Contact</a>
      </div>

      <div class="dropdown ms-auto me-2">
        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">Login</button>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="login_admin.py">Admin Login</a></li>
          <li><a class="dropdown-item" href="ridesharer_login.py">Sharer Login</a></li>
          <li><a class="dropdown-item" href="rideseeker_loginpage.py">Seeker Login</a></li>
        </ul>
      </div>

      <div class="dropdown">
        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">Register</button>
        <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="ridesharer.py">Ride Sharer</a></li>
        <li><a class="dropdown-item" href="ride_seeker.py">Ride Seeker</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav>
    <div class="form-sec">
        <div class="form-container">
            <h2>RideSharer Registration Form</h2>
            <div id="errorDisplay" class="error-box"></div>
            <div id="successDisplay" class="success-box"></div>
            <form method="post" enctype="multipart/form-data" onsubmit="return validateForm(event)">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="example@gmail.com" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Phone Number</label>
                    <input type="text" class="form-control" id="phone" name="phone" placeholder="10-digit number" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Date of Birth</label>
                    <input type="date" class="form-control" id="dob" name="dob" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Gender</label>
                    <select class="form-select" id="gender" name="gender" required>
                        <option selected disabled value="">--Select Gender--</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Aadhaar Proof</label>
                    <input type="file" class="form-control" id="aadhaar" name="aadhaar" accept=".jpg,.jpeg,.png,.pdf" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Vehicle License</label>
                    <input type="file" class="form-control" id="license" name="license" accept=".jpg,.jpeg,.png,.pdf" required />
                </div>
                <div class="mb-3">
                <label class="form-label">Profile Photo</label>
            <input type="file" name="profile_pic" id="profile_pic" class="form-control" accept="image/png, image/jpeg, image/jpg" required>
            <small class="form-text text-muted">Accepted formats: JPG, PNG</small>
        </div>
                <div class="mb-3">
                    <label class="form-label">Address</label>
                    <textarea class="form-control" name="address" id="address" required></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Country</label>
                    <select class="form-select" id="country" name="country" onchange="loadStates()" required>
                        <option selected disabled value="">--Select Country--</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">State</label>
                    <select class="form-select" id="state" name="state" onchange="loadCities()" required>
                        <option selected disabled value="">--Select State--</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">City</label>
                    <select class="form-select" id="city" name="city" required>
                        <option selected disabled value="">--Select City--</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Pincode</label>
                    <input type="text" class="form-control" id="pincode" name="pincode" placeholder="6-digit Pincode" required />
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-info" id="register" name="register">Register</button>
                </div>
            </form>
        </div>
    </div>
       <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>RideShare</h3>
                    <p>Making travel affordable, efficient, and sustainable through shared rides.</p>
                    <div class="social-links">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>

                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                       <li><a href="main.py" target="_self">Home</a></li>
                        <li><a href="about.py" target="_self">About Us</a></li>
                        <li><a href="how_it_works.py" target="_self">How It Works</a></li>
                        <li><a href="contact.py" target="_self">Contact Us</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links">
                        <li><a href="#">Daily Commute</a></li>
                        <li><a href="#">Long Distance</a></li>
                        <li><a href="#">Event Rides</a></li>
                        <li><a href="#">Airport Transfers</a></li>
                        <li><a href="#">Business Travel</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Download App</h3>
                    <p>Get the best experience with our mobile app</p>
                    <a href="#" class="d-flex align-items-center mb-2 text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-apple fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">Download on the</div>
                            <div style="font-weight: 500;">App Store</div>
                        </div>
                    </a>
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-google-play fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">GET IT ON</div>
                            <div style="font-weight: 500;">Google Play</div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="footer-bottom text-center py-3">
                <p class="mb-0">&copy; 2025 RideShare. All rights reserved.</p>
            </div>
        </div>
    </footer>


    <script>
        const locationData = {
            "India": {
                "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai"],
                "Maharashtra": ["Mumbai", "Pune", "Nagpur"],
                "Karnataka": ["Bengaluru", "Mysuru", "Mangaluru"]
            },
            "USA": {
                "California": ["Los Angeles", "San Francisco", "San Diego"],
                "Texas": ["Houston", "Dallas", "Austin"]
            },
            "Canada": {
                "Ontario": ["Toronto", "Ottawa"],
                "British Columbia": ["Vancouver", "Victoria"]
            }
        };

        window.onload = function () {
            const countrySelect = document.getElementById("country");
            for (let country in locationData) {
                let option = document.createElement("option");
                option.value = country;
                option.text = country;
                countrySelect.appendChild(option);
            }
            const today = new Date();
            const minDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
            document.getElementById('dob').max = minDate.toISOString().split('T')[0];
        };

        function loadStates() {
            const country = document.getElementById("country").value;
            const stateSelect = document.getElementById("state");
            const citySelect = document.getElementById("city");

            stateSelect.innerHTML = '<option selected disabled value="">--Select State--</option>';
            citySelect.innerHTML = '<option selected disabled value="">--Select City--</option>';

            if (locationData[country]) {
                Object.keys(locationData[country]).forEach(state => {
                    let option = document.createElement("option");
                    option.value = state;
                    option.text = state;
                    stateSelect.appendChild(option);
                });
            }
        }

        function loadCities() {
            const country = document.getElementById("country").value;
            const state = document.getElementById("state").value;
            const citySelect = document.getElementById("city");

            citySelect.innerHTML = '<option selected disabled value="">--Select City--</option>';

            if (locationData[country] && locationData[country][state]) {
                locationData[country][state].forEach(city => {
                    let option = document.createElement("option");
                    option.value = city;
                    option.text = city;
                    citySelect.appendChild(option);
                });
            }
        }

        function validateForm(event) {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const dob = document.getElementById('dob').value;
            const gender = document.getElementById('gender').value;
            const aadhaar = document.getElementById('aadhaar').value;
            const license = document.getElementById('license').value;
            const address = document.getElementById('address').value.trim();
            const profile_pic = document.getElementById('profile_pic').value;
            const country = document.getElementById('country').value;
            const state = document.getElementById('state').value;
            const city = document.getElementById('city').value;
            const pincode = document.getElementById('pincode').value.trim();

            const errorDisplay = document.getElementById('errorDisplay');
            errorDisplay.style.display = 'none';
            errorDisplay.innerHTML = '';
            let errors = [];

            if (!name) errors.push("Please enter your Name");
            if (!email) errors.push("Please enter your Email");
            if (!/^\d{10}$/.test(phone)) errors.push("Please enter a valid 10-digit phone number");
            if (!dob) errors.push("Please enter your Date of Birth");
            if (dob) {
                const birthDate = new Date(dob);
                const today = new Date();
                const minDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
                if (birthDate > minDate) errors.push("You must be at least 18 years old");
            }
            if (!gender) errors.push("Please select your Gender");
            if (!aadhaar) errors.push("Please upload your Aadhaar Card");
            if (!license) errors.push("Please upload your License");
            if (!profile_pic) errors.push("Please upload your Profile Photo");
            if (!address || address.length < 10) errors.push("Please enter a valid Address (min 10 characters)");
            if (!country) errors.push("Please select a Country");
            if (!state) errors.push("Please select a State");
            if (!city) errors.push("Please select a City");
            if (!/^\d{6}$/.test(pincode)) errors.push("Please enter a valid 6-digit Pincode");

            // Validate file types
            if (aadhaar) {
                const allowedExtensions = /(\.jpg|\.jpeg|\.png|\.pdf)$/i;
                if (!allowedExtensions.exec(aadhaar)) {
                    errors.push("Aadhaar file must be JPG, JPEG, PNG or PDF");
                }
            }
            
            if (license) {
                const allowedExtensions = /(\.jpg|\.jpeg|\.png|\.pdf)$/i;
                if (!allowedExtensions.exec(license)) {
                    errors.push("License file must be JPG, JPEG, PNG or PDF");
                }
            }
            
            if (profile_pic) {
                const allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
                if (!allowedExtensions.exec(profile_pic)) {
                    errors.push("Profile photo must be JPG, JPEG or PNG");
                }
            }

            if (errors.length > 0) {
                event.preventDefault();
                errorDisplay.innerHTML = errors.join('<br>');
                errorDisplay.style.display = 'block';
                window.scrollTo(0, 0);
                return false;
            }
            return true;
        }
    </script>
</body>
</html>""")

# Process form submission
if register is not None:
    try:
        name = form.getvalue("name")
        email = form.getvalue("email")
        phone = form.getvalue("phone")
        dob = form.getvalue("dob")

        gender = form.getvalue("gender")
        address = form.getvalue('address')
        country = form.getvalue("country")
        state = form.getvalue("state")
        city = form.getvalue("city")
        pincode = form.getvalue("pincode")
        status = "New"

        # Check if email already exists
        cur.execute("SELECT * FROM register_sharer WHERE email = %s", (email,))
        if cur.fetchone():
            print(f"""<script>alert('Email already registered. Please use a different email.');</script>""")
        else:
            # Create upload directory if it doesn't exist
            if not os.path.exists("uploads"):
                os.makedirs("uploads")

            # Handle file uploads
            def save_uploaded_file(file_field, upload_dir="uploads"):
                if file_field.filename:
                    # Sanitize filename
                    filename = re.sub(r'[^a-zA-Z0-9._-]', '_', file_field.filename)
                    # Add timestamp to avoid name conflicts
                    name, ext = os.path.splitext(filename)
                    filename = f"{name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{ext}"
                    filepath = os.path.join(upload_dir, filename)

                    with open(filepath, "wb") as f:
                        f.write(file_field.file.read())
                    return filename
                return None

            aadhaar_file = form['aadhaar']
            a_proof = save_uploaded_file(aadhaar_file)

            license_file = form['license']
            l_proof = save_uploaded_file(license_file)

            profile_file = form['profile_pic']
            u_photo = save_uploaded_file(profile_file)

            sql = """
                INSERT INTO register_sharer (name, email, phone, DOB, gender, aadhaar, license, photo, address, country, state, city, pincode, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            cur.execute(sql, (name, email, phone, dob, gender, a_proof, l_proof, u_photo, address, country, state, city, pincode, status))
            con.commit()

            print(f"""<script>
                alert('Ride Sharer Form Submitted Successfully');
                window.location.href = 'ridesharer_login.py';
            </script>""")
    except Exception as e:
        print(f"<script>alert('Error occurred: {str(e)}');</script>")
    finally:
        con.close()
