#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
print("Content-Type: text/html\r\n\r\n")

import cgi, cgitb
cgitb.enable()

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RideShare - Admin Login</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="static/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #1355e3, #032337, #3cc5ff);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

        .form-sec {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 16px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.25);
        }

        h2 {
            color: white;
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
        }

        .form-label,
        .form-check-label {
            color: white;
        }

        .form-control {
            background-color: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 10px;
            height: 45px;
            font-size: 15px;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.4);
            outline: none;
        }

        .btn-light {
            font-weight: bold;
            font-size: 16px;
            border-radius: 10px;
            padding: 10px 20px;
        }

        footer {
            position: relative;
            bottom: 0;
            width: 100%;
            color: #fff;
            text-align: center;
            padding: 15px 0;
            background-color: rgba(0, 0, 0, 0.3);
        }
    </style>
</head>

<body>
  <!-- Navigation Bar -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#" style="color: rgba(14, 93, 230, 0.963);"><i
                        class="bi bi-car-front-fill"></i> Ride Sharer</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" href="main.html" style="color: rgba(14, 93, 230, 0.963);">Home</a>
                        <a class="nav-link" href="about.html" style="color: rgba(14, 93, 230, 0.963);">About</a>
                        <a class="nav-link" href="how_it_works.html" style="color: rgba(14, 93, 230, 0.963);">How it
                            Works</a>
                        <a class="nav-link" href="contact.html" style="color: rgba(14, 93, 230, 0.963);">Contact</a>
                    </div>

                    <div class="dropdown ms-auto me-2">
                        <button class="btn btn-outline dropdown-toggle login" type="button" id="dropdownMenuButton1"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Login
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li><a class="dropdown-item" href="admin_user.py">Admin Login</a></li>
                            <li><a class="dropdown-item" href="ridesharer_login.py">Sharer Login</a></li>
                            <li><a class="dropdown-item" href="rideseeker_loginpage.py">Seeker Login</a></li>
                        </ul>
                    </div>

                    <div class="dropdown">
                        <button class="btn btn-outline dropdown-toggle register" type="button" id="dropdownMenuButton2"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Register
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
                            <li><a class="dropdown-item" href="ridesharer.py">Ride Sharer</a></li>
                            <li><a class="dropdown-item" href="ride_seeker.py">Ride Seeker</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!-- Admin Login Form -->
    <section class="form-sec">
        <div class="form-container">
            <h2>Admin Login</h2>
            <form onsubmit="return validateLogin(event);">
                <div class="mb-3">
                    <label class="form-label" for="username">Username</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" />
                </div>

                <div class="mb-3">
                    <label class="form-label" for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" />
                </div>

                <div class="d-flex justify-content-between">
                    <a href="main.html" class="btn btn-light">Cancel</a>
                    <button type="submit" class="btn btn-light">Login</button>
                </div>
            </form>
        </div>
    </section>

   <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>RideShare</h3>
                    <p>Making travel affordable, efficient, and sustainable through shared rides.</p>
                    <div class="social-links">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>

                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="main.html">Home</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="how_it_works.html">How It Works</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links">
                        <li><a href="#">Daily Commute</a></li>
                        <li><a href="#">Long Distance</a></li>
                        <li><a href="#">Event Rides</a></li>
                        <li><a href="#">Airport Transfers</a></li>
                        <li><a href="#">Business Travel</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Download App</h3>
                    <p>Get the best experience with our mobile app</p>
                    <a href="#" class="d-flex align-items-center mb-2 text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-apple fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">Download on the</div>
                            <div style="font-weight: 500;">App Store</div>
                        </div>
                    </a>
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-google-play fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">GET IT ON</div>
                            <div style="font-weight: 500;">Google Play</div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="footer-bottom text-center py-3">
                <p class="mb-0">&copy; 2025 RideShare. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- JS -->
    <script>
        function validateLogin(event) {
            event.preventDefault();

            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value.trim();

            if (!username) {
                alert("Please enter your username.");
                return false;
            }

            if (!password) {
                alert("Please enter your password.");
                return false;
            }

            if (username === "dani" && password === "2103") {
                alert("Login successful!");
                window.location.href = "admin_dashboard.py";
            } else {
                alert("Invalid username or password.");
            }

            return false;
        }
    </script>

</body>
</html>
""")
