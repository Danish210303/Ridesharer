#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html; charset=utf-8\r\n\r\n")

import cgi, cgitb, pymysql, os
from datetime import datetime
cgitb.enable()

# DB connection
con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()

form = cgi.FieldStorage()
d = form.getvalue('id')

# Confirmation logic before HTML
id_a = form.getvalue('id_a')
confirm = form.getvalue('confirm')

if confirm is not None and id_a:
    update_query = f"""UPDATE order_table SET status='Confirm' WHERE id='{id_a}'"""
    cur.execute(update_query)
    con.commit()
    print(f"""<script>alert("Ride Confirmed"); location.href='ridesharer_requested.py?id={d}';</script>""")

# Fetch new bookings
query = """SELECT * FROM order_table WHERE status='New'"""
cur.execute(query)
bookings = cur.fetchall()

# Get Sharer Info
u = f"""SELECT name,photo FROM register_sharer WHERE id='{d}' """
cur.execute(u)
u1 = cur.fetchone()
image_path = f"database/{u1[1]}" if u1[1] else "https://i.ibb.co/4f3J9Cx/avatar.png"

# Start HTML
print(f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RideShare Connect | Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        :root {{
            --header-height: 70px;
            --sidebar-width: 280px;
        }}
        
        body {{
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: var(--header-height);
            min-height: 100vh;
            overflow-x: hidden;
        }}
        
       .admin-header {{
            background: linear-gradient(135deg, #0449de, #1d5c9b);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: var(--header-height);
            z-index: 1050;
            display: flex;
            align-items: center;
            padding: 0 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }}
        
        .logo {{
            display: flex;
            align-items: center;
            gap: 15px;
        }}
        
        .logo i {{
            font-size: 25px;
        }}
        
        .logo h1 {{
            font-size: 24px;
            font-weight: 600;
            margin: 0;
        }}
        
        
        .sidebar {{
            position: fixed;
            top: var(--header-height);
            left: -300px;
            width: var(--sidebar-width);
            height: calc(100vh - var(--header-height));
            background: white;
            padding: 20px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            z-index: 1040;
            overflow-y: auto;
        }}
        
        .sidebar.show {{
            left: 0;
        }}
        
        .sidebar-header {{
            padding: 20px 25px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            align-items: center;
        }}
        
        .sidebar-header img {{
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }}
        
        .user-info h3 {{
            font-size: 20px;
            margin: 0 0 3px 0;
        }}
        
        .user-info p {{
            color: #3f37c9;
            font-size: 15px;
            margin: 0;
        }}
        
        .menu-item {{
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 20px;
            color: #212529;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
            border-bottom: 1px solid #f5f5f5;
        }}
        
        .menu-item:hover,
        .menu-item.active {{
            background: #4361ee;
            color: white;
        }}
        
        .menu-item i {{
            font-size: 18px;
        }}
        
        .main-content {{
            padding: 20px;
            transition: all 0.3s ease;
        }}
        
        .menu-toggle {{
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            margin-right: 15px;
            display: none;
        }}
        
        .sidebar-overlay {{
            position: fixed;
            top: var(--header-height);
            left: 0;
            width: 100%;
            height: calc(100vh - var(--header-height));
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1030;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }}
        
        .sidebar-overlay.show {{
            opacity: 1;
            visibility: visible;
        }}
        
        /* Desktop styles */
        @media (min-width: 992px) {{
            .sidebar {{
                left: 0; /* Always visible */
            }}
            
            .main-content {{
                margin-left: var(--sidebar-width);
            }}
        }}
        
        /* Mobile styles */
        @media (max-width: 991.98px) {{
            .menu-toggle {{
                display: block;
            }}
            
            .main-content {{
                margin-left: 0;
            }}
        }}
        
        /* Small screens */
        @media (max-width: 767.98px) {{
            :root {{
                --header-height: 60px;
            }}
            
            .main-content {{
                padding: 15px;
            }}
            
            .logo h1 {{
                font-size: 18px;
            }}
            
            .table-responsive {{
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }}
        }}
    </style>
</head>
<body>

<!-- Header -->
<header class="admin-header">
    <button class="menu-toggle" id="menuToggle">
        <i class="bi bi-list"></i>
    </button>
    <div class="logo">
        <i class="bi bi-car-front-fill"></i>
        <h1>Ride Sharer Dashboard</h1>
    </div>
    <div class="ms-auto d-flex align-items-center">
        <div class="text-end me-3 d-none d-md-block">
            <h5 class="mb-0">{u1[0]}</h5>
            <small>Ride Sharer</small>
        </div>
        <img src="{image_path}" class="rounded-circle" width="40" height="40" alt="profile" style="object-fit: cover;">
    </div>
</header>

<!-- Sidebar Overlay -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <img src="{image_path}" class="rounded-circle" alt="profile">
        <div class="user-info ms-3">
            <h3>{u1[0]}</h3>
            <p>Ride Sharer</p>
        </div>
    </div>
    <div class="sidebar-menu">
        <a href="ridesharer_profile.py?id={d}" class="menu-item"><i class="bi bi-person-square"></i> Profile</a>
        <div class="dropdown">
            <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown"><i class="bi bi-car-front-fill"></i> My Rides</a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="ridesharer_postride.py?id={d}">Post Ride</a></li>
                <li><a class="dropdown-item" href="ridesharer_viewride.py?id={d}">View Ride</a></li>
            </ul>
        </div>
        <div class="dropdown">
            <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
                <i class="bi bi-journal-text"></i> Booking Request
            </a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="ridesharer_requested.py?id={d}">Requested</a></li>
                <li><a class="dropdown-item" href="ridesharer_confirmed.py?id={d}">Confirm</a></li>
                <li><a class="dropdown-item" href="ridesharer_cancel.py?id={d}">Cancel</a></li>
                <li><a class="dropdown-item" href="ridesharer_history.py?id={d}">Booking History</a></li>
            </ul>
        </div>
        <a href="main.py?id={d}"  class="menu-item"><i class="bi bi-arrow-left-circle"></i> Logout</a>
    </div>
</aside>

<!-- Main Content -->
<main class="main-content" id="mainContent">
    <h3 class="mb-4">Requested Rides</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-striped bg-white shadow-sm">
            <thead class="table-primary">
                <tr>
                    <th>Seeker Name</th>
                    <th>Seeker Email</th>
                    <th>Seeker Mobile</th>
                    <th>Pickup</th>
                    <th>Drop</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
""")

# Ride bookings
for i in bookings:
    cur.execute(f"SELECT name,email,phone FROM register_seeker WHERE id='{i[14]}'")
    d1 = cur.fetchone()

    print(f"""
<tr>
  <td>{d1[0]}</td>
  <td>{d1[1]}</td>
  <td>{d1[2]}</td>
  <td>{i[2]}</td>
  <td>{i[3]}</td>
  <td>{i[4]}</td>
  <td>{i[5]}</td>
  <td><span class="text-success">{i[18]}</span></td>
  <td>
    <button type="button" data-bs-toggle="modal" data-bs-target="#modal{i[0]}" class="btn btn-sm btn-success">Confirm</button>

    <div class="modal fade" id="modal{i[0]}" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="post" action="ridesharer_requested.py?id={d}">
            <div class="modal-header">
              <h5 class="modal-title">Confirm Ride</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <input type="hidden" name="id_a" value="{i[0]}">
              <p>Do you want to confirm the ride?</p>
            </div>
            <div class="modal-footer">
              <input class="btn btn-success" type="submit" value="confirm" name="confirm">
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal" aria-label="Close">Close</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </td>
</tr>
""")

# End HTML
print("""
            </tbody>
        </table>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    
    menuToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        sidebar.classList.toggle('show');
        sidebarOverlay.classList.toggle('show');
    });
    
    sidebarOverlay.addEventListener('click', function() {
        sidebar.classList.remove('show');
        sidebarOverlay.classList.remove('show');
    });
    
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', function() {
            if (window.innerWidth <= 991.98) {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('show');
            }
        });
    });
    
    window.addEventListener('resize', function() {
        if (window.innerWidth > 991.98) {
            sidebar.classList.remove('show');
            sidebarOverlay.classList.remove('show');
        }
    });
});
</script>

</body>
</html>
""")

# Close database connection
con.close()
