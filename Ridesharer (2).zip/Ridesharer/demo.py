#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html; charset=utf-8\r\n\r\n")

import cgi, cgitb, pymysql, os
cgitb.enable()

# DB Connection
con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()

form = cgi.FieldStorage()
user = form.getvalue('id')

# Get user details
cur.execute("SELECT * FROM register_seeker WHERE id = %s", (user,))
rows = cur.fetchall()
user_name = rows[0][1] if rows else "Seeker User"

# HTML Header
print("""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>RideShare Connect | Seeker Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <style>
    body {
      background-color: #f0f2f5;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      padding-top: 80px;
    }
    
    .admin-header {
      background: linear-gradient(135deg, #0449de, #1d5c9b);
      color: white;
      padding: 15px 0;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }
    
    .logo {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    
    .logo i {
      font-size: 25px;
    }
    
    .logo h1 {
      font-size: 1.5rem;
      font-weight: 600;
      margin: 0;
    }
    
    .sidebar {
      background: white;
      height: calc(100vh - 80px);
      overflow-y: auto;
      padding: 25px 0;
      position: fixed;
      top: 80px;
      width: 300px;
      left: -300px;
      transition: all 0.3s;
      z-index: 999;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    }
    
    .sidebar.show {
      left: 0;
    }
    
    .sidebar-header {
      padding: 20px 25px;
      border-bottom: 1px solid #e9ecef;
      display: flex;
      align-items: center;
    }
    
    .sidebar-header img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      object-fit: cover;
      background: #e9ecef;
    }
    
    .user-info h3 {
      font-size: 22px;
      margin-bottom: 5px;
    }
    
    .user-info p {
      color: #3f37c9;
      font-size: 17px;
      margin: 0;
    }
    
    .sidebar-menu {
      padding: 20px 0;
    }
    
    .menu-item {
      display: flex;
      align-items: center;
      gap: 15px;
      padding: 12px 25px;
      color: #212529;
      text-decoration: none;
      transition: all 0.3s ease;
      font-weight: 500;
    }
    
    .menu-item:hover,
    .menu-item.active {
          background: #4361ee;
          color: white;
    }
    
    .menu-item i {
      font-size: 20px;
    }
    
    .dropdown-menu {
      background-color: #fff;
      border-radius: 8px;
      padding: 0;
      border: 1px solid #ddd;
      margin-left: 20px;
    }
    
    .dropdown-item {
      padding: 10px 20px;
      color: #333;
      font-size: 14px;
    }
    
    .dropdown-item:hover {
      background-color: #f0f0f0;
      color: #000;
    }
    
    .profile-card {
      background-color: #fff;
      border-radius: 10px;
      padding: 40px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
      max-width: 600px;
      margin: 30px auto;
      text-align: center;
    }
    
    .profile-pic {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 20px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }
    
    .overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 998;
      display: none;
    }
    
    .overlay.show {
      display: block;
    }
    
    .navbar-toggler {
      border: none;
      color: white;
      font-size: 1.5rem;
    }
    
    @media (min-width: 992px) {
      .sidebar {
        left: 0;
      }
      .main-content {
        margin-left: 300px;
      }
      .navbar-toggler {
        display: none;
      }
      .overlay {
        display: none !important;
      }
    }
  </style>
</head>
""")

if rows:
    image_path = f"database/{rows[0][14]}" if rows[0][14] else "https://i.ibb.co/4f3J9Cx/avatar.png"

print(f"""
<body>
  <!-- Header -->
  <div class="admin-header">
    <div class="container">
      <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
          <button class="navbar-toggler me-3 d-lg-none" type="button" onclick="toggleSidebar()">
            <i class="bi bi-list"></i>
          </button>
          <div class="logo">
            <i class="bi bi-car-front-fill"></i>
            <h1>Ride Seeker Dashboard</h1>
          </div>
        </div>
        <div class="d-flex align-items-center">
          <div class="me-3 text-end d-none d-md-block">
            <h5 class="mb-0">{user_name}</h5>
            <small>Ride Seeker</small>
          </div>
          <img src="{image_path}" class="rounded-circle" width="50" alt="profile">
        </div>
      </div>
    </div>
  </div>

  <!-- Sidebar Overlay -->
  <div class="overlay" onclick="toggleSidebar()"></div>

  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <img src="{image_path}" width="50" class="rounded-circle" alt="profile">
      <div class="user-info ms-3">
        <h3>{user_name}</h3>
        <p>Ride Seeker</p>
      </div>
    </div>
    <div class="sidebar-menu">
      <a href="./rideseeker_dashboard.py?id={user}" class="menu-item active">
        <i class="bi bi-person-square"></i> Profile
      </a>
      <a href="./rideseeker_search.py?id={user}" class="menu-item">
        <i class="bi bi-search"></i> Search Rides
      </a>
      <div class="dropdown">
        <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
          <i class="bi bi-journal-text"></i> My Booking
        </a>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="./rideseeker_bookingpending.py?id={user}">Requested</a></li>
          <li><a class="dropdown-item" href="./rideseeker_bookingcompleted.py?id={user}">Confirmed</a></li>
          <li><a class="dropdown-item" href="./rideseeker_bookingcancel.py?id={user}">Cancel</a></li>
          <li><a class="dropdown-item" href="./rideseeker_bookinghistory.py?id={user}">Booking History</a></li>
        </ul>
      </div>
      <a href="main.py?user_id={user}" class="menu-item logout">
        <i class="bi bi-arrow-left-circle"></i> Logout
      </a>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">
""")

# Fetch user info again
cur.execute("SELECT * FROM register_seeker WHERE id = %s", (user,))
d = cur.fetchall()

for i in d:
    pic = "database/" + i[14]
    print(f"""
      <div class="profile-card">
        <h3>{i[1]}</h3>
        <div class="profile-info">
          <form method="post" enctype="multipart/form-data">
            <label for="ab">
              <img src="{pic}" alt="Profile Picture" class="profile-pic" style="cursor:pointer;">
            </label>
            <input type="file" name="change_photo" id="ab" style="display:none;" onchange="this.form.submit()">
            <input type="hidden" name="id_a" value="{i[0]}">
          </form>
          <p><strong>Email:</strong> {i[2]}</p>
          <p><strong>Phone:</strong> {i[3]}</p>
          <button type="button" data-bs-toggle="modal" data-bs-target="#modal{i[0]}" class="btn btn-info">Profile Update</button>

          <div class="modal fade" id="modal{i[0]}">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Ride Seeker Profile Update</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <form method="post">
                    <input type="hidden" name="id_a" value="{i[0]}">
                    <div class="mb-3">
                      <label class="form-label">Email</label>
                      <input type="email" name="email" class="form-control" value="{i[2]}" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Password</label>
                      <input type="password" name="password" class="form-control" value="{i[13]}" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Phone</label>
                      <input type="number" name="phone" class="form-control" value="{i[3]}" required>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <input type="submit" class="btn btn-primary" value="Update" name="submit">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    """)

print("""
    </div>
  </div>

  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      const overlay = document.querySelector('.overlay');
      sidebar.classList.toggle('show');
      overlay.classList.toggle('show');
    }
  </script>
</body>
</html>
""")

# ---------- Profile Update ----------
submit = form.getvalue("submit")
if submit is not None:
    id_a = form.getvalue("id_a")
    email = form.getvalue("email")
    password = form.getvalue("password")
    phone = form.getvalue("phone")

    update_query = "UPDATE register_seeker SET email=%s, user_password=%s, phone=%s WHERE id=%s"
    cur.execute(update_query, (email, password, phone, id_a))
    con.commit()

    print(f"""<script>alert("Profile Updated Successfully");location.href='rideseeker_profile.py?id={user}';</script>""")

# ---------- Photo Upload ----------
if 'change_photo' in form:
    pht = form['change_photo']
    id_a = form.getvalue("id_a")
    if pht.filename:
        imgg = os.path.basename(pht.filename)
        file_path = os.path.join("database", imgg)

        with open(file_path, "wb") as f:
            f.write(pht.file.read())

        query = "UPDATE register_seeker SET profile_photo=%s WHERE id=%s"
        cur.execute(query, (imgg, id_a))
        con.commit()

        print(f"""<script>alert("Photo Updated Successfully");location.href='rideseeker_profile.py?id={user}';</script>""")

con.close()
