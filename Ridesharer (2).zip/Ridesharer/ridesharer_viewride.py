#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html\r\n\r\n")

import cgi, cgitb, pymysql, os
from datetime import datetime

cgitb.enable()

# Connect to database
con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()

form = cgi.FieldStorage()
d = form.getvalue('id')
# Fetch user data using the passed ID
cur.execute("SELECT * FROM register_sharer WHERE id=%s", (d,))
row = cur.fetchone()
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RideShare Connect | My Rides</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
        }
        
        /* Fixed header */
        .admin-header {
            background: linear-gradient(135deg, #0449de, #1d5c9b);
            color: white;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
            padding: 15px 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        /* Sidebar styling */
        .sidebar {
            background: white;
            position: fixed;
            top: 70px;
            left: 0;
            height: calc(100vh - 70px);
            width: 300px;
            padding: 20px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            z-index: 999;
            overflow-y: auto;
        }
        
        /* Main content area */
        .main-content {
            margin-left: 280px;
            margin-top: 70px;
            padding: 20px;
            transition: all 0.3s ease;
        }
        
        /* Mobile menu button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            margin-right: 15px;
        }
        
        /* Logo styling */
          .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo i {
            font-size: 25px;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
        }

        
        /* Sidebar header */
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            align-items: center;
        }
        
       .sidebar-header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }

        .user-info h3 {
            font-size: 20px;
            margin: 0 0 3px 0;
        }

        .user-info p {
            color: #3f37c9;
            margin: 0;
            font-size: 15px;
        }
        
        /* Menu items */
        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 20px;
            color: #212529;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
            border-bottom: 1px solid #f5f5f5;
        }
        .menu-item:hover, .menu-item.active {
            background: #4361ee;
            color: white;
        }
        .menu-item i {
            font-size: 18px;
        }
        
        /* Ride cards */
        .ride-card {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        /* Overlay for mobile */
        .overlay {
            position: fixed;
            top: 70px;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 998;
            display: none;
        }
        
        /* Responsive adjustments */
        @media (max-width: 991px) {
            .sidebar {
                margin-top:-30px;
                left: -300px;
                height:100vh;
            }
            .sidebar.show {
                left: 0;
            }
            .main-content {
                margin-left: 0;
            }
            .mobile-menu-btn {
                display: block;
            }
        }
        
        @media (max-width: 576px) {
            .logo h1 {
                font-size: 18px;
            }
            .admin-header {
                padding: 10px 15px;
            }
        }
    </style>
</head>""")

if row:
    image_path = f"database/{row[8]}" if row[8] else "https://i.ibb.co/4f3J9Cx/avatar.png"
    print(f"""
<body>
    <!-- Fixed Header -->
    <div class="admin-header">
        <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <button class="mobile-menu-btn" id="mobileMenuBtn"><i class="bi bi-list"></i></button>
                <div class="logo">
                    <i class="bi bi-car-front-fill"></i>
                    <h1>Ride Sharer Dashboard</h1>
                </div>
            </div>
            <div class="d-flex align-items-center">
                <div class="me-3 text-end d-none d-md-block">
                    <h5 class="mb-0">{row[1]}</h5>
                    <small>Ride Sharer</small>
                </div>
                <img src="{image_path}" class="rounded-circle" width="40" alt="profile" />
            </div>
        </div>
    </div>

    <!-- Overlay for mobile sidebar -->
    <div class="overlay" id="overlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="{image_path}" alt="profile">
            <div class="user-info ms-3">
                <h3>{row[1]}</h3>
                <p>Ride Sharer</p>
            </div>
        </div>
        <div class="sidebar-menu">
            <a href="ridesharer_profile.py?id={d}" class="menu-item"><i class="bi bi-person-square"></i> Profile</a>
            <div class="dropdown">
                <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="bi bi-car-front-fill"></i> My Rides
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="ridesharer_postride.py?id={d}">Post Ride</a></li>
                    <li><a class="dropdown-item" href="ridesharer_viewride.py?id={d}">View Ride</a></li>
                </ul>
            </div>
            <div class="dropdown">
                <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="bi bi-journal-text"></i> Booking Request
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="ridesharer_requested.py?id={d}">Requested</a></li>
                    <li><a class="dropdown-item" href="ridesharer_confirmed.py?id={d}">Confirm</a></li>
                    <li><a class="dropdown-item" href="ridesharer_cancel.py?id={d}">Cancel</a></li>
                    <li><a class="dropdown-item" href="ridesharer_history.py?id={d}">Booking History</a></li>
                </ul>
            </div>
            <a href="main.py?id={d}"  class="menu-item logout">
                <i class="bi bi-arrow-left-circle"></i> Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <h3 class="mb-4">My Posted Rides</h3>""")

    # Fetch all rides
    cur.execute("SELECT * FROM post_ride WHERE sharer_id=%s", (d,))
    rides = cur.fetchall()

    for ride in rides:
        print(f""" 
        <!-- Ride Card -->
        <div class="ride-card">
            <h5>From {ride[1]} to {ride[2]}</h5>
            <p class="mb-2">Date: {ride[3]} | Time: {ride[4]}</p>
            <p class="mb-2">Vehicle: {ride[10]} | Seats: {ride[5]} | Fare: ₹{ride[6]}</p>
            <p class="mb-3">Notes: {ride[11]}</p>
            <button type="button" data-bs-toggle="modal" data-bs-target="#modal{ride[0]}"
                class="btn btn-danger btn-sm"><i class="bi bi-trash3-fill"></i> Delete Ride</button>
            
            <!-- Modal -->
            <div class="modal fade" id="modal{ride[0]}">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="post">
                            <div class="modal-header">
                                <h5 class="modal-title">Cancel Ride</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <p>Are you sure you want to cancel this ride?</p>
                                <input type="hidden" name="id_a" value="{ride[0]}">
                            </div>
                            <div class="modal-footer">
                                <input type="submit" name="submit" value="Yes" class="btn btn-danger">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
             <button type="button" data-bs-toggle="modal" data-bs-target="#modal1{ride[0]}"
                class="btn btn-info btn-sm"></i> Edit Ride</button>
            
            <!-- Modal -->
            <div class="modal fade" id="modal1{ride[0]}">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="post">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Ride</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                            <form method="post" enctype="multipart/form-data">
                             <input type="hidden" name="id_e" value="{ride[0]}">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">From</label>
                            <input type="text" name="source" class="form-control" value="{ride[1]}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">To</label>
                            <input type="text" name="destination" class="form-control" value="{ride[2]}" >
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Departure Date</label>
                            <input type="date" name="date" class="form-control" value="{ride[3]}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Departure Time</label>
                            <input type="time" name="time" class="form-control" value="{ride[4]}">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Seats Available</label>
                            <input type="number" name="seats" class="form-control" min="1" max="8" value="{ride[5]}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fare (INR)</label>
                            <input type="number" name="fare" class="form-control" value="{ride[6]}">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Vehicle Type</label>
                        <input type="text" name="vehicle_type" class="form-control" value="{ride[9]}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Vehicle Number</label>
                        <input type="text" name="vehicle_number" class="form-control" value="{ride[11]}">
                    </div>
                   
                  
                    <div class="modal-footer">
                                <input type="submit" name="edit" value="Yes" class="btn btn-danger">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            </div>
                    
                </form>
                                
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
            
        </div>
        
        """)

    # Handle ride deletion
    delt = form.getvalue('id_a')
    submit = form.getvalue('submit')
    if submit is not None and delt:
        cur.execute("DELETE FROM post_ride WHERE id=%s", (delt,))
        con.commit()
        print(f"""<script>alert("Ride deleted successfully");location.href='ridesharer_viewride.py?id={d}'</script>""")

    edit = form.getvalue('edit')
    if edit is not None:
        up = form.getvalue('id_e')
        source = form.getvalue('source')
        destination = form.getvalue('destination')
        date = form.getvalue('date')

        time_val = form.getvalue('time')
        seats = form.getvalue('seats')
        fare = form.getvalue('fare')
        vehicle_type = form.getvalue('vehicle_type')
        vehicle_number = form.getvalue('vehicle_number')


        da = f'''update post_ride set source='{source}',destination='{destination}',date='{date}',time='{time_val}',seats='{  seats}',fare='{fare}',vehicle_type='{vehicle_type}',vehicle_number='{vehicle_number}'  where id='{up}' '''
        cur.execute(da)
        con.commit()
        print(f"""<script>alert("Edit successfully");location.href='ridesharer_viewride.py?id={d}'</script>""")

    print("""
    </div> <!-- End of .main-content -->

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.getElementById('sidebar');
        const menuBtn = document.getElementById('mobileMenuBtn');
        const overlay = document.getElementById('overlay');
        const mainContent = document.getElementById('mainContent');
        
        // Toggle sidebar
        menuBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            sidebar.classList.toggle('show');
            overlay.style.display = sidebar.classList.contains('show') ? 'block' : 'none';
        });
        
        // Close sidebar when clicking overlay
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.style.display = 'none';
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            if (window.innerWidth < 992) {
                if (!sidebar.contains(e.target) && e.target !== menuBtn) {
                    sidebar.classList.remove('show');
                    overlay.style.display = 'none';
                }
            }
        });
        
        // Close sidebar when a menu item is clicked (mobile)
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', function() {
                if (window.innerWidth < 992) {
                    sidebar.classList.remove('show');
                    overlay.style.display = 'none';
                }
            });
        });
    });
    </script>
</body>
</html>
""")

else:
    print("""
    <div class="container mt-5">
        <div class="alert alert-danger text-center">
            <h4>No user found with the given ID.</h4>
        </div>
    </div>
    </body>
    </html>
    """)

con.close()
