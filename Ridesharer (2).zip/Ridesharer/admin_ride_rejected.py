#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html; charset=utf-8\r\n\r\n")
from datetime import datetime
import cgi, cgitb, pymysql
cgitb.enable()

# Connect to MySQL
con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()

print("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideShare Admin Dashboard</title>

    <!-- Bootstrap CSS + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

    <style>
        :root {
            --sidebar-width: 250px;
            --header-height: 70px;
            --primary-color: #4361ee;
            --danger-color: #dc3545;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .admin-header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: linear-gradient(135deg, #0449de, #1d5c9b);
            color: white;
            height: var(--header-height);
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar {
            position: fixed;
            top: var(--header-height);
            left: 0;
            width: var(--sidebar-width);
            height: calc(100vh - var(--header-height));
            background-color: white;
            overflow-y: auto;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            z-index: 999;
        }

        .sidebar.collapsed {
            left: calc(-1 * var(--sidebar-width));
        }

        .sidebar-header {
            padding: 20px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #ddd;
        }

        .user-info {
            margin-left: 15px;
        }

        .user-info h3 {
            margin: 0;
            font-size: 18px;
        }

        .user-info p {
            margin: 0;
            font-size: 13px;
            color: var(--primary-color);
        }

        .menu-item {
            display: block;
            padding: 12px 20px;
            color: #212529;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover, .menu-item.active {
               background-color: #4361ee;
               color: white;
        }

        .dropdown-menu {
            background-color: #f8f9fa;
            border: none;
            box-shadow: none;
            margin-left: 20px;
            padding: 0;
        }

        .dropdown-item {
            padding: 10px 20px;
            font-size: 14px;
        }

        .dropdown-item:hover {
            background-color: rgba(67, 97, 238, 0.1);
        }

        .content-wrapper {
            margin-left: var(--sidebar-width);
            padding: calc(var(--header-height) + 20px) 20px 20px;
            min-height: calc(100vh - var(--header-height));
            transition: all 0.3s ease;
        }

        .content-wrapper.expanded {
            margin-left: 0;
        }

        .table img {
            cursor: pointer;
            transition: transform 0.3s;
            max-width: 50px;
            height: auto;
            border-radius: 4px;
        }

        .table img:hover {
            transform: scale(1.05);
        }

        .menu-toggle {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            display: none;
        }

        .badge-cancelled {
            background-color: var(--danger-color);
            padding: 6px 10px;
            border-radius: 6px;
            font-size: 0.85rem;
        }

        @media (max-width: 992px) {
            .sidebar {
                left: calc(-1 * var(--sidebar-width));
            }

            .sidebar.show {
                left: 0;
            }

            .content-wrapper {
                margin-left: 0;
            }

            .menu-toggle {
                display: block;
            }
        }

        @media (max-width: 768px) {
            .table td, .table th {
                padding: 8px;
                font-size: 0.9rem;
            }
            
            .menu-item {
                padding: 10px 15px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="admin-header d-flex justify-content-between align-items-center px-3 px-md-4">
    <div class="d-flex align-items-center gap-3">
        <button class="menu-toggle me-2" id="menuToggle">
            <i class="bi bi-list"></i>
        </button>
        <i class="bi bi-car-front-fill fs-4 d-none d-md-block"></i>
        <h4 class="mb-0">RideShare Admin Panel</h4>
    </div>
    <div class="d-flex align-items-center gap-3">
        <div class="text-end d-none d-md-block">
            <h6 class="mb-0">Admin User</h6>
            <small>Administrator</small>
        </div>
       
    </div>
</div>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="user-info">
            <h3>Admin User</h3>
            <p>Administrator</p>
        </div>
    </div>
    <a href="./admin_user.py" class="menu-item">
        <i class="bi bi-person-check-fill me-2"></i> Users
    </a>
    <div class="dropdown">
        <a class="menu-item dropdown-toggle active" data-bs-toggle="dropdown" href="#">
            <i class="bi bi-car-front-fill me-2"></i> Rider Management
        </a>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="./admin_ride_new.py">New</a></li>
            <li><a class="dropdown-item" href="./admin_ride_approve.py">Approve</a></li>
            <li><a class="dropdown-item active" href="./admin_ride_rejected.py">Reject</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="menu-item dropdown-toggle" data-bs-toggle="dropdown" href="#">
            <i class="bi bi-journal-text me-2"></i> Booking Status
        </a>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="./admin_booking_pending.py">Pending</a></li>
            <li><a class="dropdown-item" href="./admin_booking_confirm.py">Confirmed</a></li>
            <li><a class="dropdown-item" href="./admin_booking_cancel.py">Cancelled</a></li>
            <li><a class="dropdown-item" href="./admin_booking_history.py">Booking History</a></li>
        </ul>
    </div>
    <a href="main.html" class="menu-item mt-4">
        <i class="bi bi-arrow-left-circle me-2"></i> Logout
    </a>
</div>

<!-- Main Content -->
<div class="content-wrapper" id="contentWrapper">
    <div class="container-fluid">
        <div class="card shadow">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0">Rejected Ride Sharers</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone No</th>
                                <th>DOB</th>
                                <th>Aadhar Proof</th>
                                <th>License</th>
                                <th>Address</th>
                            
                            </tr>
                        </thead>
                        <tbody>
""")

# Fetch and display data
data = """SELECT * FROM register_sharer WHERE status='Rejected'"""
cur.execute(data)
records = cur.fetchall()

for i in records:
    a_card = "database/" + i[6]
    l_card = "database/" + i[7]

    # Format date properly
    dob = i[4]
    if isinstance(dob, str):
        try:
            dob = datetime.strptime(dob, "%Y-%m-%d").strftime("%d-%m-%Y")
        except ValueError:
            dob = dob
    else:
        dob = dob.strftime("%d-%m-%Y")

    print(f"""
        <tr>
            <td>{i[1]}</td>
            <td>{i[2]}</td>
            <td>{i[3]}</td>
            <td>{dob}</td>
            <td><a href="{a_card}" target="_blank"><img src="{a_card}" class="img-thumbnail"></a></td>
            <td><a href="{l_card}" target="_blank"><img src="{l_card}" class="img-thumbnail"></a></td>
            <td>{i[9]}, {i[10]}</td>
        
        </tr>
    """)

print("""
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const contentWrapper = document.getElementById('contentWrapper');

        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            contentWrapper.classList.toggle('expanded');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 992) {
                const isClickInsideSidebar = sidebar.contains(event.target);
                const isClickOnMenuToggle = menuToggle.contains(event.target);
                
                if (!isClickInsideSidebar && !isClickOnMenuToggle) {
                    sidebar.classList.remove('show');
                    contentWrapper.classList.remove('expanded');
                }
            }
        });

        // Handle window resize
        window.addEventListener('resize', function() {
            if (window.innerWidth > 992) {
                sidebar.classList.remove('show');
                contentWrapper.classList.remove('expanded');
            }
        });
    });
</script>

</body>
</html>
""")

# Close database connection
cur.close()
con.close()
