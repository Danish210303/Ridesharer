#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys
import io
import cgi
import cgitb
import pymysql
import os
from datetime import datetime
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
print("Content-Type: text/html\r\n\r\n")

cgitb.enable()

# Get form data
form = cgi.FieldStorage()
d = form.getvalue('id')

# Connect to database
con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()

# Handle form submission first
submit = form.getvalue('submit')
if submit is not None:
    try:
        # Get form values
        source = form.getvalue('source')
        destination = form.getvalue('destination')
        date = form.getvalue('date')

        time_val = form.getvalue('time')
        seats = form.getvalue('seats')
        fare = form.getvalue('fare')
        vehicle_type = form.getvalue('vehicle_type')
        vehicle_number = form.getvalue('vehicle_number')
        notes = form.getvalue('notes')
        sharer_id = form.getvalue('id_a')
        sharer_username = form.getvalue('user')
        status = "New"




        # Initialize file names
        card1 = card2 = card3 = None

        # Handle file uploads
        if not os.path.exists("database"):
            os.makedirs("database")

        # RC Book
        if 'rc_book' in form and form['rc_book'].filename:
            rc_book = form['rc_book']
            card1 = os.path.basename(rc_book.filename)
            with open("database/" + card1, "wb") as f:
                f.write(rc_book.file.read())

        # Insurance Proof
        if 'i_proof' in form and form['i_proof'].filename:
            i_proof = form['i_proof']
            card2 = os.path.basename(i_proof.filename)
            with open("database/" + card2, "wb") as f:
                f.write(i_proof.file.read())

        # Vehicle Picture
        if 'v_pic' in form and form['v_pic'].filename:
            v_pic = form['v_pic']
            card3 = os.path.basename(v_pic.filename)
            with open("database/" + card3, "wb") as f:
                f.write(v_pic.file.read())

        # Insert into database
        sql = """INSERT INTO post_ride 
        (source, destination, date, time, seats, fare, rc_book, insurance_proof, 
         vehicle_type, vehicle_picture, vehicle_number, notes, sharer_id, sharer_username, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""

        cur.execute(sql, (source, destination, date, time_val, seats, fare, card1, card2,
                         vehicle_type, card3, vehicle_number, notes, sharer_id, sharer_username, status))
        con.commit()

        print(f"""<script>
            alert('Ride Posted Successfully');
            window.location.href='ridesharer_viewride.py?id={d}';
        </script>""")
        sys.exit()

    except Exception as e:
        print(f"""<script>alert('Error: {str(e)}');</script>""")
        con.rollback()

# Fetch user data
cur.execute("SELECT * FROM register_sharer WHERE id=%s", (d,))
da = cur.fetchall()

# HTML starts here
print("""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>RideShare Connect | Post a Ride</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body {
        margin: 0;
        padding: 0;
        background-color: #f0f2f5;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        padding-top: 80px;
    }
    
    /* Header Styles */
    .admin-header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        background: linear-gradient(135deg, #0449de, #1d5c9b);
        color: white;
        padding: 15px 20px;
        z-index: 1000;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
      .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo i {
            font-size: 25px;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
        }

    
    /* Sidebar Toggle Button */
    .sidebar-toggle {
        background: none;
        border: none;
        color: white;
        font-size: 1.5rem;
        display: none;
    }
    
  /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 80px;
            left: 0;
            width: 300px;
            height: calc(100vh - 80px);
            background: white;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow-y: auto;
            transition: all 0.3s ease;
            z-index: 999;
        }

        .sidebar.collapsed {
            left: -300px;
        }

        /* Sidebar Sections */
        .sidebar-header {
            padding: 20px 25px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            align-items: center;
        }

        .sidebar-header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }

      
        .user-info h3 {
            font-size: 20px;
            margin: 0 0 3px 0;
        }

        .user-info p {
            color: #3f37c9;
            margin: 0;
            font-size: 15px;
        }
        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 25px;
            color: #212529;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: #4361ee;
            color: white;
            border-left: 3px solid white;
        }

        .menu-item i {
            font-size: 20px;
        }
    .main-content {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: calc(100vh - 80px); /* Full height minus header */
        padding: 20px;
        margin-left: 300px; /* Keep sidebar spacing on desktop */
    }
    /* Form Styles */
    .form-label { 
        font-weight: 500; 
    }
    
    .form-control, .form-select { 
        border-radius: 10px;
        padding: 10px 15px;
    }
    
    .btn-success {
        background-color: #2ecc71;
        border-color: #2ecc71;
        padding: 10px 0;
        font-weight: 500;
    }
    
    .btn-success:hover {
        background-color: #27ae60;
        border-color: #27ae60;
    }
    
    /* Responsive Styles */
    @media (max-width: 992px) {
        .sidebar {
            margin-top:-30px;
            left: -300px;
            height:100vh;
        }
        
        .sidebar.show {
            left: 0;
        }
        
        .main-content {
            margin-left: 0;
        }
        
        .sidebar-toggle {
            display: block;
        }
    }
    
    @media (max-width: 768px) {
        .logo h1 {
            font-size: 20px;
        }
        
        .admin-header {
            padding: 10px 15px;
        }
    }
    
    @media (max-width: 576px) {
        .logo h1 {
            font-size: 18px;
        }
        
        .main-content {
            padding: 15px;
        }
        .admin-header {
            padding: 10px 15px;
        }
    }
  </style>
</head>
<body>
""")

for i in da:
    img = "database/" + i[8] if i[8] else "https://i.ibb.co/4f3J9Cx/avatar.png"
    print(f"""
    <!-- Header with Toggle Button -->
    <div class="admin-header">
        <div class="d-flex align-items-center">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="logo">
                <i class="bi bi-car-front-fill"></i>
                <h1 class="d-none d-md-block">Ride Sharer Dashboard</h1>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <div class="me-3 text-end d-none d-md-block">
                <h5 class="mb-0">{i[1]}</h5>
                <small>Ride Sharer</small>
            </div>
            <img src="{img}" class="rounded-circle" width="50" alt="profile" />
        </div>
    </div>

    <!-- Sidebar -->
     <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="{img}" class="rounded-circle" width="50" alt="profile">
            <div class="user-info ms-3">
                <h3>{i[1]}</h3>
                <p>Ride Sharer</p>
            </div>
        </div>
        <div class="sidebar-menu">
            <a href="ridesharer_profile.py?id={d}" class="menu-item"><i class="bi bi-person-square"></i> Profile</a>
            
            <div class="dropdown">
                <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="bi bi-car-front-fill"></i> My Rides
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item active" href="ridesharer_postride.py?id={d}">Post Ride</a></li>
                    <li><a class="dropdown-item" href="ridesharer_viewride.py?id={d}">View Ride</a></li>
                </ul>
            </div>
            
            <div class="dropdown">
                <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="bi bi-journal-text"></i> Booking Request
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="ridesharer_requested.py?id={d}">Requested</a></li>
                    <li><a class="dropdown-item" href="ridesharer_confirmed.py?id={d}">Confirm</a></li>
                    <li><a class="dropdown-item" href="ridesharer_cancel.py?id={d}">Cancel</a></li>
                    <li><a class="dropdown-item" href="ridesharer_history.py?id={d}">Booking History</a></li>
                </ul>
            </div>
            
            <a href="main.py?sharer_id={d}" class="menu-item logout">
                <i class="bi bi-arrow-left-circle"></i> Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="card shadow-sm">
            <div class="card-body">
                <h3 class="mb-4">Post a Ride</h3>
                <form method="post" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">From</label>
                            <input type="text" name="source" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">To</label>
                            <input type="text" name="destination" class="form-control" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Departure Date</label>
                            <input type="date" name="date" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Departure Time</label>
                            <input type="time" name="time" class="form-control" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Seats Available</label>
                            <input type="number" name="seats" class="form-control" min="1" max="8" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fare (INR)</label>
                            <input type="number" name="fare" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Vehicle Type</label>
                        <input type="text" name="vehicle_type" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Vehicle Number</label>
                        <input type="text" name="vehicle_number" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">RC Book</label>
                        <input type="file" name="rc_book" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Insurance Proof</label>
                        <input type="file" name="i_proof" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Vehicle Picture</label>
                        <input type="file" name="v_pic" class="form-control" accept=".jpg,.jpeg,.png">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Additional Notes</label>
                        <textarea name="notes" class="form-control" rows="3"></textarea>
                    </div>
                    <input type="hidden" name="id_a" value="{i[0]}">
                    <input type="hidden" name="user" value="{i[1]}">
                    <button type="submit" name="submit" class="btn btn-success w-100">
                        <i class="bi bi-check-circle"></i> Post Ride
                    </button>
                </form>
            </div>
        </div>
    </div>""")
print(""""
    
    <script>
        // Toggle sidebar on mobile
        document.getElementById('sidebarToggle').addEventListener('click', function(e) {
            e.stopPropagation();
            document.getElementById('sidebar').classList.toggle('show');
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const toggleBtn = document.getElementById('sidebarToggle');
            
            if (window.innerWidth <= 992 && 
                !sidebar.contains(event.target) && 
                !toggleBtn.contains(event.target)) {
                sidebar.classList.remove('show');
            }
        });
    </script>
""")

print("""
</body>
</html>
""")

con.close()
