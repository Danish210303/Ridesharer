#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
print("content-type:text/html \r\n\r\n")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideShare - Connect & Travel Together</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="static/style.css">
    <style>
        .hero {
            padding: 5rem 5% 3rem;
            text-align: center;
            background-color: rgba(26, 42, 108, 0.8);
            color: white;
            position: relative;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(7, 134, 225, 0.9) 0%, rgba(40, 174, 197, 0.7) 100%);
        }

        .hero-content {
            position: relative;
            max-width: 900px;
            margin: 0 auto;
            padding: 2rem;
        }

        .hero h1 {
            font-size: 3.5rem;
            margin-bottom: 1rem;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        .hero p {
            font-size: 1.3rem;
            max-width: 700px;
            margin: 0 auto 2rem;
            line-height: 1.7;
        }

        .cta-button {
            background: #ffcc00;
            color: #1a2a6c;
            padding: 10px 25px;
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }

        .cta-button:hover {
            background: #eddb11;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }



        /* Contact Section */
        .contact-section {
            display: flex;
            flex-wrap: wrap;
            padding: 5rem 5%;
            max-width: 1400px;
            margin: 0 auto;
            gap: 3rem;
        }

        .contact-info {
            flex: 1;
            min-width: 300px;
        }

        .contact-form {
            flex: 1;
            min-width: 300px;
        }

        .section-title {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
            color: var(--primary);
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -10px;
            width: 80px;
            height: 4px;
            background: var(--secondary);
            border-radius: 2px;
        }

        .contact-description {
            font-size: 1.1rem;
            line-height: 1.8;
            margin-bottom: 2rem;
            color: var(--gray);
        }

        .info-card {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            transition: all 0.3s ease;
        }

        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }

        .info-item {
            display: flex;
            gap: 20px;
            margin-bottom: 1.5rem;
            align-items: flex-start;
        }

        .info-item:last-child {
            margin-bottom: 0;
        }

        .info-icon {
            width: 60px;
            height: 60px;
            background: rgba(26, 42, 108, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .info-icon i {
            font-size: 1.8rem;
            color: var(--primary);
        }

        .info-content h3 {
            font-size: 1.3rem;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .info-content p,
        .info-content a {
            color: var(--gray);
            text-decoration: none;
            transition: all 0.3s ease;
            line-height: 1.6;
        }

        .info-content a:hover {
            color: var(--primary);
        }

        .hours-list {
            list-style: none;
        }

        .hours-list li {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }

        .hours-list li:last-child {
            border-bottom: none;
        }

        .hours-list li span:first-child {
            font-weight: 500;
        }

        /* Contact Form */
        .form-container {
            background: white;
            padding: 2.5rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }

        .form-control {
            width: 100%;
            padding: 14px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(26, 42, 108, 0.1);
        }

        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }

        .submit-btn {
            background: var(--primary);
            color: white;
            padding: 15px 40px;
            font-size: 1.1rem;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .submit-btn:hover {
            background: #2c3e82;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .faq-section {
            padding: 25 15%;
            max-width: 1200px;
            margin: 0 auto;
        }

        .faq-container {
            margin-top: 3rem;
        }

        .faq-item {
            margin-bottom: 20px;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .faq-question {
            padding: 30px;
            font-size: 1.2rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--primary);
        }

        /* CTA Section */
        .cta {
            padding: 5rem 5%;
            text-align: center;
            background: linear-gradient(90deg, #1a2a6c, #ffaa00);
            color: var(--primary);
        }

        .cta h2 {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
        }

        .cta p {
            max-width: 700px;
            margin: 0 auto 2.5rem;
            font-size: 1.2rem;
            font-weight: 500;
        }

        .cta-button.dark {
            background: var(--primary);
            color: white;
            padding: 15px 40px;
            font-size: 1.1rem;
        }

        .cta-button.dark:hover {
            background: #2c3e82;
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#" style="color: rgba(14, 93, 230, 0.963);"><i class="bi bi-car-front-fill"></i> Ride Sharer</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                 <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" style="color: rgba(14, 93, 230, 0.963);" href="main.py">Home</a>
                        <a class="nav-link" style="color: rgba(14, 93, 230, 0.963);" href="about.py">About</a>
                        <a class="nav-link" style="color: rgba(14, 93, 230, 0.963);" href="how_it_works.py">How it
                            Works</a>
                        <a class="nav-link" style="color: rgba(14, 93, 230, 0.963);" href="contact.py">Contact</a>
                    </div>

                    <div class="dropdown ms-auto me-2">
                        <button class="btn btn-outline dropdown-toggle login" type="button" id="dropdownMenuButton1"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Login
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li><a class="dropdown-item" href="login_admin.py">Admin Login</a></li>
                            <li><a class="dropdown-item" href="ridesharer_login.py">Sharer Login</a></li>
                            <li><a class="dropdown-item" href="rideseeker_loginpage.py">Seeker Login</a></li>
                        </ul>
                    </div>

                    <div class="dropdown">
                        <button class="btn btn-outline dropdown-toggle register" type="button" id="dropdownMenuButton2"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Register
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
                            <li><a class="dropdown-item" href="ridesharer.py">Ride Sharer</a></li>
                            <li><a class="dropdown-item" href="ride_seeker.py">Ride Seeker</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>


    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Contact Ride Sharer</h1>
            <p>We're here to help! Reach out to us with questions, feedback, or support needs. Our team is ready to
                assist you 24/7.</p>
            <a href="#" class="cta-button">Send a Message</a>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="contact-info">
            <h2 class="section-title">Get In Touch</h2>
            <p class="contact-description">Have questions or need assistance? Our support team is available around the
                clock to help you with any issues or inquiries you may have.</p>

            <div class="info-card">
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="info-content">
                        <h3>Our Headquarters</h3>
                        <p>123 BU Lane<br>Krishnagiri, Tamil Nadu<br>India</p>
                    </div>
                </div>
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <div class="info-content">
                        <h3>Call Us</h3>
                        <p>
                            <a href="tel:+91 9344379243">tel:+91 9344379243</a><br>
                            <a href="tel:91 8220275049">tel:+91 8220275049</a>
                        </p>
                    </div>
                </div>
                <div class="info-item">
                    <div class="info-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="info-content">
                        <h3>Email Us</h3>
                        <p>
                            <a href="mailto:support@rideshare.com">ridesharer21@gmail.com</a><br>
                            <a href="mailto:partners@rideshare.com">ridesharer20@gmail.com</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="info-card">
                <h3 style="margin-bottom: 1.5rem; color: var(--primary);">Support Hours</h3>
                <ul class="hours-list">
                    <li><span>Monday - Friday</span> <span>6:00 AM - 12:00 AM</span></li>
                    <li><span>Saturday</span> <span>7:00 AM - 1:00 AM</span></li>
                    <li><span>Sunday</span> <span>7:00 AM - 11:00 PM</span></li>
                    <li><span>Emergency Support</span> <span>24/7</span></li>
                </ul>
            </div>
        </div>

        <div class="contact-form" id="contact-form">
            <div class="form-container">
                <h2 class="section-title">Send Us a Message</h2>
                <form>
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" class="form-control" placeholder="Enter your name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" class="form-control" placeholder="Enter your email" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number (Optional)</label>
                        <input type="tel" id="phone" class="form-control" placeholder="Enter your phone number">
                    </div>

                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <select id="subject" class="form-control" required>
                            <option value="" disabled selected>Select a subject</option>
                            <option value="support">Support Request</option>
                            <option value="feedback">Feedback & Suggestions</option>
                            <option value="partnership">Partnership Inquiry</option>
                            <option value="business">Business Solutions</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="message">Your Message</label>
                        <textarea id="message" class="form-control" placeholder="How can we help you?"
                            required></textarea>
                    </div>

                    <button type="submit" class="submit-btn">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </form>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq-section">
        <h2 class="section-title" style="text-align: center;">Frequently Asked Questions</h2>
        <div class="faq-container">
            <div class="faq-item">
                <div class="faq-question">
                    How can I get support for a ride issue? <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>If you experienced an issue during your ride, please contact our support team immediately through
                        the app or via our 24/7 support line at +1 (800) RIDE-NOW. For faster resolution, please have
                        your trip details ready including driver name, ride ID, and approximate time of the issue.</p>
                </div>
            </div>
            <div class="faq-item">
                <div class="faq-question">
                    How do I become a Ride Sharer driver? <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>To become a driver, visit our Driver Portal on our website or download the Ride Sharer Driver
                        app. You'll need to complete an online application, provide required documents (driver's
                        license, vehicle registration, insurance), pass a background check, and complete a vehicle
                        inspection. The entire process typically takes 5-7 business days.</p>
                </div>
            </div>
            <div class="faq-item">
                <div class="faq-question">
                    What's your response time for support requests? <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>We strive to respond to all support requests within 1 hour for urgent matters and within 24 hours
                        for general inquiries. For account security issues or payment problems, we prioritize these
                        requests and typically respond within 30 minutes. You can also reach our live support 24/7 for
                        immediate assistance.</p>
                </div>
            </div>
            <div class="faq-item">
                <div class="faq-question">
                    Do you offer corporate accounts? <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>Yes, we offer corporate accounts with special features including centralized billing, customized
                        travel policies, detailed reporting, and dedicated account management. To set up a corporate
                        account, please contact our business solutions team at business@rideshare.com or call +1 (415)
                        555-0199 during business hours.</p>
                </div>
            </div>
            <div class="faq-item">
                <div class="faq-question">
                    How can I provide feedback about my driver? <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>After each ride, you'll have the opportunity to rate your driver and provide comments directly in
                        the app. If you'd like to provide more detailed feedback, you can email feedback@rideshare.com.
                        All feedback is reviewed by our quality assurance team and used to improve our service.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <h2>Need Help Right Now?</h2>
        <p>Contact our 24/7 support team for immediate assistance</p>
        <a href="tel:+18007433669" class="cta-button dark">
            <i class="fas fa-phone-alt"></i> Call Support: (800) RIDE-NOW
        </a>
    </section>

    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>RideShare</h3>
                    <p style="margin-bottom: 20px; color:gray;">Making travel affordable, efficient, and sustainable
                        through shared rides.</p>
                    <div class="social-links">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>

                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="main.py" target="_self">Home</a></li>
                        <li><a href="about.py" target="_self">About Us</a></li>
                        <li><a href="how_it_works.py" target="_self">How It Works</a></li>
                        <li><a href="contact.py" target="_self">Contact Us</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links">
                        <li><a href="#">Daily Commute</a></li>
                        <li><a href="#">Long Distance</a></li>
                        <li><a href="#">Event Rides</a></li>
                        <li><a href="#">Airport Transfers</a></li>
                        <li><a href="#">Business Travel</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Download App</h3>
                    <p style="margin-bottom: 15px; color: #cccccc;">Get the best experience with our mobile app</p>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <a href="#"
                            style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; color: white; text-decoration: none; transition: all 0.3s;">
                            <i class="bi bi-apple" style="font-size: 1.5rem;"></i>
                            <div>
                                <div style="font-size: 0.8rem;">Download on the</div>
                                <div style="font-weight: 500;">App Store</div>
                            </div>
                        </a>
                        <a href="#"
                            style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px; color: white; text-decoration: none; transition: all 0.3s;">
                            <i class="bi bi-google-play" style="font-size: 1.5rem;"></i>
                            <div>
                                <div style="font-size: 0.8rem;">GET IT ON</div>
                                <div style="font-weight: 500;">Google Play</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 RideShare. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>


</html>""")
