#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html; charset=utf-8\r\n\r\n")
from datetime import datetime
import cgi, cgitb, pymysql
cgitb.enable()

# Connect to MySQL
con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()

print("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideShare Admin Dashboard</title>

    <!-- Bootstrap CSS + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

    <style>
        :root {
            --sidebar-width: 250px;
            --header-height: 70px;
            --primary-color: #4361ee;
            --pending-color: #ffc107;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .admin-header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: linear-gradient(135deg, #0449de, #1d5c9b);
            color: white;
            height: var(--header-height);
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px 30px;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo i {
            font-size: 25px;
        }

        .logo h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 0;
        }

        .sidebar {
            position: fixed;
            top: var(--header-height);
            left: 0;
            width: var(--sidebar-width);
            height: calc(100vh - var(--header-height));
            background-color: white;
            overflow-y: auto;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            z-index: 999;
        }

         .sidebar-header {
            padding: 20px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #ddd;
        }

        .user-info {
            margin-left: 15px;
        }

        .user-info h3 {
            margin: 0;
            font-size: 18px;
        }

        .user-info p {
            margin: 0;
            font-size: 13px;
            color: var(--primary-color);
        }


        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 20px;
            color: #212529;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .menu-item:hover, .menu-item.active {
            background-color: var(--primary-color);
            color: white;
        }

        .dropdown-menu {
            background-color: #fff;
            border-radius: 8px;
            padding: 0;
            margin-left: 20px;
        }

        .dropdown-item {
            padding: 10px 20px;
        }

        .content-wrapper {
            margin-left: var(--sidebar-width);
            padding: calc(var(--header-height) + 30px) 30px 30px;
            min-height: calc(100vh - var(--header-height));
            transition: all 0.3s ease;
        }

        .container-booking {
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            max-height: 70vh;
            overflow-y: auto;
        }

        .status-pending {
            background-color: var(--pending-color);
            color: #000;
        }

        .menu-toggle {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            display: none;
        }

        @media (max-width: 992px) {
            .sidebar {
                left: calc(-1 * var(--sidebar-width));
            }

            .sidebar.show {
                left: 0;
            }

            .content-wrapper {
                margin-left: 0;
            }

            .menu-toggle {
                display: block;
            }
        }

        @media (max-width: 768px) {
            .admin-header {
                padding: 15px;
            }
            
            .table th, .table td {
                padding: 8px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="admin-header d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-3">
        <button class="menu-toggle me-2" id="menuToggle">
            <i class="bi bi-list"></i>
        </button>
        <div class="logo">
            <i class="bi bi-car-front-fill"></i>
            <h1>RideShare Admin Panel</h1>
        </div>
    </div>
    <div class="d-flex align-items-center gap-3">
        <div class="text-end d-none d-md-block">
            <h6 class="mb-0">Admin User</h6>
            <small>Administrator</small>
        </div>
       
    </div>
</div>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="user-info">
            <h3>Admin User</h3>
            <p>Administrator</p>
        </div>
    </div>
    <div class="sidebar-menu">
        <a href="./admin_user.py" class="menu-item">
            <i class="bi bi-person-check-fill"></i> Users
        </a>
        <div class="dropdown">
            <a href="#" class="menu-item dropdown-toggle" data-bs-toggle="dropdown">
                <i class="bi bi-car-front-fill"></i> Rider Management
            </a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="./admin_ride_new.py">New</a></li>
                <li><a class="dropdown-item" href="./admin_ride_approve.py">Approve</a></li>
                <li><a class="dropdown-item" href="./admin_ride_rejected.py">Reject</a></li>
            </ul>
        </div>
        <div class="dropdown">
            <a href="#" class="menu-item dropdown-toggle active" data-bs-toggle="dropdown">
                <i class="bi bi-journal-text"></i> Booking Status
            </a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item " href="./admin_booking_pending.py">Pending</a></li>
                <li><a class="dropdown-item" href="./admin_booking_confirm.py">Confirmed</a></li>
                <li><a class="dropdown-item active" href="./admin_booking_cancel.py">Cancelled</a></li>
                <li><a class="dropdown-item" href="./admin_booking_history.py">Booking History</a></li>
            </ul>
        </div>
        <a href="main.py" class="menu-item">
            <i class="bi bi-arrow-left-circle"></i> Logout
        </a>
    </div>
</div>

<!-- Main Content -->
<div class="content-wrapper" id="contentWrapper">
    <div class="container-booking">
        <h2 class="mb-4">Cancel Bookings</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Booking ID</th>
                        <th>Driver Name</th>
                        <th>Driver Contact</th>
                        <th>Date</th>
                        <th>User Name</th>
                        <th>User Contact</th>
                        <th>From</th>
                        <th>To</th>
                    
                        <th>Fare</th>
                        <th>View More</th>
                    </tr>
                </thead>
                <tbody>
""")

# Fetch and display booking data
query = """SELECT * FROM order_table WHERE status='Cancel'"""
cur.execute(query)
bookings = cur.fetchall()

for booking in bookings:
    # Get driver details
    cur.execute("SELECT name,email,phone,address,DOB,gender,country,state,city FROM register_sharer WHERE id=%s", (booking[16],))
    driver = cur.fetchone()

    # Get user details
    cur.execute("SELECT name,email,phone,address,country,state,city,dob,gender FROM register_seeker WHERE id=%s", (booking[14],))
    user = cur.fetchone()

    print(f"""
    <tr>
        <td>#RS{booking[0]}</td>
        <td>{driver[0] if driver else 'N/A'}</td>
        <td>{driver[2] if driver else 'N/A'}</td>
        <td>{booking[4]}</td>
        <td>{user[0] if user else 'N/A'}</td>
        <td>{user[2] if user else 'N/A'}</td>
        <td>{booking[2]}</td>
        <td>{booking[3]}</td>
       
        <td>₹{booking[7]}</td>
        <td>
            <button type="button" data-bs-toggle="modal" data-bs-target="#modal{booking[0]}" class="btn btn-sm btn-primary">More</button>
            
            <!-- Modal -->
            <div class="modal fade" id="modal{booking[0]}" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Booking Details</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Driver Information</h6>
                                    <p><b>Name:</b> {driver[0] if driver else 'N/A'}</p>
                                    <p><b>Email:</b> {driver[1] if driver else 'N/A'}</p>
                                    <p><b>Phone:</b> {driver[2] if driver else 'N/A'}</p>
                                    <p><b>Address:</b> {driver[3] if driver else 'N/A'}, {driver[6] if driver else 'N/A'}, {driver[7] if driver else 'N/A'}, {driver[8] if driver else 'N/A'}</p>
                                    <p><b>DOB:</b> {driver[4] if driver else 'N/A'}</p>
                                    <p><b>Gender:</b> {driver[5] if driver else 'N/A'}</p>
                                </div>
                                <div class="col-md-6">
                                    <h6>User Information</h6>
                                    <p><b>Name:</b> {user[0] if user else 'N/A'}</p>
                                    <p><b>Email:</b> {user[1] if user else 'N/A'}</p>
                                    <p><b>Phone:</b> {user[2] if user else 'N/A'}</p>
                                    <p><b>Address:</b> {user[3] if user else 'N/A'}, {user[4] if user else 'N/A'}, {user[5] if user else 'N/A'}, {user[6] if user else 'N/A'}</p>
                                    <p><b>DOB:</b> {user[7] if user else 'N/A'}</p>
                                    <p><b>Gender:</b> {user[8] if user else 'N/A'}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </td>
    </tr>
    """)

print("""
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const contentWrapper = document.getElementById('contentWrapper');

        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            contentWrapper.classList.toggle('expanded');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 992) {
                const isClickInsideSidebar = sidebar.contains(event.target);
                const isClickOnMenuToggle = menuToggle.contains(event.target);
                
                if (!isClickInsideSidebar && !isClickOnMenuToggle) {
                    sidebar.classList.remove('show');
                    contentWrapper.classList.remove('expanded');
                }
            }
        });

        // Handle window resize
        window.addEventListener('resize', function() {
            if (window.innerWidth > 992) {
                sidebar.classList.remove('show');
                contentWrapper.classList.remove('expanded');
            }
        });
    });
</script>

</body>
</html>
""")

# Close database connection
cur.close()
con.close()
