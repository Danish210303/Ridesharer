#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("Content-Type: text/html; charset=utf-8\r\n\r\n")

import cgi, cgitb, pymysql, os
cgitb.enable()

# DB connection
con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()
form = cgi.FieldStorage()
user = form.getvalue('id')

# Fetch booking data
query = """SELECT * FROM order_table WHERE status='Completed' """
cur.execute(query)
bookings = cur.fetchall()

cur.execute("SELECT * FROM register_seeker WHERE id = %s", (user,))
rows = cur.fetchall()
user_name = rows[0][1] if rows else "Seeker User"
img = "database/" + rows[0][14]

# HTML Output
print("""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>RideShare Connect | My Bookings</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

  <style>
    :root {
    --primary-color: #4361ee;
    --header-height: 80px;
    --sidebar-width: 300px;
}

body {
    padding-top: var(--header-height);
    background-color: #f8f9fa;
    margin: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* FIXED HEADER */
.admin-header {
    background: linear-gradient(135deg, #0449de, #1d5c9b);
    color: white;
    padding: 0 20px;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    height: var(--header-height);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.logo {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo i {
    font-size: 25px;
}

.logo h1 {
    font-size: 18px;
    font-weight: 600;
    margin: 0;
}


    .sidebar {
      background: white;
      height: calc(100vh - 80px);
      overflow-y: auto;
      padding: 25px 0;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
      position: fixed;
      top: 80px;
      width: 300px;
      left: 0;
      transition: all 0.3s ease;
      z-index: 1020;
    }

    .sidebar.collapsed {
      left: -250px;
    }

    .dashboard-content {
      margin-left: 250px;
      padding: 30px;
      transition: all 0.3s ease;
    }

    .dashboard-content.expanded {
      margin-left: 0;
    }

    .menu-item {
      display: flex;
      align-items: center;
      gap: 15px;
      padding: 12px 25px;
      color: #212529;
      text-decoration: none;
      transition: 0.3s;
      font-weight: 500;
    }

    .menu-item:hover,
    .menu-item.active {
      background: #4361ee;
      color: white;
    }

    .sidebar-toggle {
      background: none;
      border: none;
      color: white;
      font-size: 1.5rem;
      margin-right: 15px;
      display: none;
    }

    .dropdown-menu {
      border: none;
      box-shadow: none;
      padding: 0;
    }

    .dropdown-item {
      padding: 8px 25px 8px 50px;
    }

    .dropdown-item:hover {
      background-color: #e9ecef;
    }
    
  .dashboard-content {
    margin-left: 280px;
    padding: 30px;
    transition: all 0.3s ease;
    display: flex;
    justify-content: center; /* Center horizontally */
  }

  .dashboard-content.expanded {
    margin-left: 0;
  }

  .content-wrapper {
    max-width: 1000px; /* Set a max width for center content */
    width: 100%;
  }

    @media (max-width: 992px) {
      .sidebar {
        left: -250px;
      }
      
      .sidebar.show {
        left: 0;
      }
      
      .dashboard-content {
        margin-left: 0;
      }
      
      .sidebar-toggle {
        display: block;
      }
    }

    @media (max-width: 768px) {
      .table-responsive {
        overflow-x: auto;
      }
    }
  </style>
</head>
""")

print(f"""
<body>
  <!-- Header -->
  <div class="admin-header d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
      <button class="sidebar-toggle" id="sidebarToggle">
        <i class="bi bi-list"></i>
      </button>
     <div class="logo d-flex align-items-center">
        <i class="bi bi-car-front-fill me-2"></i>
        <h1 class="mb-0 fs-5">Ride Seeker Dashboard</h1>
      </div>
    </div>
    <div class="d-flex align-items-center">
      <div class="me-3 text-end d-none d-md-block">
        <h5 class="mb-0">{user_name}</h5>
        <small>Ride Seeker</small>
      </div>
      <img src="{img}" class="rounded-circle" width="50" alt="profile">
    </div>
  </div>

  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <div class="sidebar-header d-flex align-items-center px-4 mb-4">
      <img src="{img}" class="rounded-circle me-3" width="50" height="50" alt="profile">
      <div>
        <h5 class="mb-0">{user_name}</h5>
        <small>Ride Seeker</small>
      </div>
    </div>
    <a href="./rideseeker_dashboard.py?id={user}" class="menu-item"><i class="bi bi-person-square"></i> Profile</a>
    <a href="./rideseeker_search.py?id={user}" class="menu-item"><i class="bi bi-search"></i> Search Rides</a>
    <div class="dropdown">
      <a href="#" class="menu-item active dropdown-toggle" data-bs-toggle="dropdown">
        <i class="bi bi-journal-text"></i> My Booking
      </a>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="./rideseeker_bookingpending.py?id={user}">Requested</a></li>
        <li><a class="dropdown-item" href="./rideseeker_bookingcompleted.py?id={user}">Confirmed</a></li>
        <li><a class="dropdown-item" href="./rideseeker_bookingcancel.py?id={user}">Cancel</a></li>
        <li><a class="dropdown-item active" href="./rideseeker_bookinghistory.py?id={user}">Booking History</a></li>
      </ul>
    </div>
    <a href="main.py?user_id={user}" class="menu-item mt-5"><i class="bi bi-arrow-left-circle"></i> Logout</a>
  </div>

 <!-- Scrollable Content Area -->
<div class="dashboard-content" id="content">
  <div class="content-wrapper">
    <h3 class="mb-4">Booking History</h3>
    <div class="table-responsive bg-white rounded shadow-sm">
      <table class="table table-bordered table-striped bg-white">
        <thead class="table-primary">
          <tr>
            <th>Sharer Name</th>
            <th>Sharer Email</th>
            <th>Sharer Mobile</th>
            <th>Pickup</th>
            <th>Drop</th>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
            <th>Feedback</th>
          </tr>
        </thead>
        <tbody>
          <!-- Your loop output here -->

""")

# Loop through bookings
for i in bookings:
    feed = i[19]

    # Fetch Sharer Info by ID
    cur.execute("SELECT name, email, phone FROM register_sharer WHERE id=%s", (i[14],))
    sharer_data = cur.fetchone()

    # Begin HTML table row
    print(f"""
    <tr>
        <td>{sharer_data[0]}</td>
        <td>{sharer_data[1]}</td>
        <td>{sharer_data[2]}</td>
        <td>{i[2]}</td>
        <td>{i[3]}</td>
        <td>{i[4]}</td>
        <td>{i[5]}</td>
        <td><span class="badge bg-success">{i[18]}</span></td>
    """)

    # Feedback logic
    if feed and feed.lower() != "null":
        print("<td><span class='text-muted'>Feedback submitted</span></td>")
    else:
        print(f"""
        <td>
            <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#modal{i[0]}">
              <i class="bi bi-chat-left-text"></i> Feedback
            </button>

            <!-- Modal -->
            <div class="modal fade" id="modal{i[0]}" tabindex="-1">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title">Provide Feedback</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <form method="post">
                      <input type="hidden" name="order_id" value="{i[0]}">
                      <div class="mb-3">
                        <label class="form-label">Your Feedback</label>
                        <textarea name="feedback" class="form-control" rows="3" placeholder="Share your experience..."></textarea>
                      </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" name="submit" class="btn btn-primary" value="Submit Feedback">
                    </form>
                  </div>
                </div>
              </div>
            </div>
        </td>
        </tr>
        """)

id_a = form.getvalue('order_id')
feedback = form.getvalue('feedback')
submit = form.getvalue('submit')

if submit is not None:
    data = """UPDATE order_table SET feedback=%s WHERE id=%s"""
    cur.execute(data,(feedback,id_a))
    con.commit()
    print(f"""<script>alert("Thank You for your feedback!");location.href='rideseeker_bookinghistory.py?id={user}';</script>""")

con.commit()

# Closing HTML
print("""
        </tbody>
      </table>
    </div>
  </div>

  <script>
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
      e.stopPropagation(); // Prevent event bubbling
      document.getElementById('sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(event) {
      const sidebar = document.getElementById('sidebar');
      const toggleBtn = document.getElementById('sidebarToggle');
      
      if (window.innerWidth <= 992 && 
          !sidebar.contains(event.target) && 
          !toggleBtn.contains(event.target)) {
        sidebar.classList.remove('show');
      }
    });
    
    // Prevent dropdown from closing sidebar
    document.querySelectorAll('.dropdown-menu').forEach(function(element) {
      element.addEventListener('click', function(e) {
        e.stopPropagation();
      });
    });
  </script>
</body>
</html>
""")
