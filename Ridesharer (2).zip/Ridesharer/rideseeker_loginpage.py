#!C:\Users\danis\AppData\Local\Programs\Python\Python311\python.exe
print("content-type:text/html \r\n\r\n")
import cgi, cgitb, pymysql, os
cgitb.enable()

con = pymysql.connect(host="localhost", user="root", password="", database="ridesharer")
cur = con.cursor()
form = cgi.FieldStorage()

# Handle forgot password request
if 'forgot_username' in form and 'new_password' in form:
    username = form.getvalue('forgot_username')
    new_password = form.getvalue('new_password')

    # Check if username exists and get email
    cur.execute("SELECT id, email FROM register_seeker WHERE user_name=%s", (username,))
    user_data = cur.fetchone()

    if user_data:
        user_id, user_email = user_data

        # Update database with new password
        cur.execute("UPDATE register_seeker SET user_password=%s WHERE user_name=%s", (new_password, username))
        con.commit()

        # Send email notification
        try:
            import smtplib
            from email.mime.text import MIMEText
            from email.mime.multipart import MIMEMultipart

            sender_email = "danishappu33@gmail.com"  # Replace with your email
            sender_password = "kmor wemo zzch dnhi"# Replace with your app password
            receiver_email = user_email

            subject = "RideShare Password Reset Confirmation"
            body = f"""
Hello {username},

Your password has been successfully reset.

Your new login details:
Username: {username}
Password: {new_password}

You can now log in at: http://localhost/rideseeker_loginpage.py

If you did not request this change, please contact support immediately.

RideShare Team
"""

            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = receiver_email
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))

            with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
                server.login(sender_email, sender_password)
                server.sendmail(sender_email, receiver_email, msg.as_string())

            print("""
            <script>
                alert('Password updated successfully! An email has been sent.');
            </script>
            """)

        except Exception as e:
            print(f"""
            <script>
                alert('Password updated successfully, but email sending failed: {str(e)}');
            </script>
            """)

    else:
        print("""
        <script>
            alert('Username not found! Please try again.');
        </script>
        """)

# Handle login
user = form.getvalue("user")
password = form.getvalue("password")
login = form.getvalue("login")

if login is not None:
    data = f"""select id from register_seeker where user_name='{user}' AND user_password='{password}' """
    cur.execute(data)
    con.commit()
    da = cur.fetchone()
    if da:
        print(f"""<script> alert('Login Successfully'); location.href='rideseeker_dashboard.py?id={da[0]}';</script>""")
    else:
        print(f"""<script> alert('user not found');location.href='rideseeker_loginpage.py'; </script>""")

# HTML starts
print("""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>RideShare - Connect & Travel Together</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" />
        <link rel="stylesheet" href="static/style.css">
        <style>
            body {
                background: linear-gradient(135deg, #1355e3, #032337, #3cc5ff);
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0; padding: 0;
            }
            .form-sec {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 40px 20px;
            }
            .form-container {
                background-color: rgba(255, 255, 255, 0.15);
                backdrop-filter: blur(8px);
                padding: 30px;
                border-radius: 16px;
                width: 600px;
                max-width: 100%;
                box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.25);
            }
            h2 {
                color: white;
                text-align: center;
                margin-bottom: 20px;
                font-size: 28px;
                font-weight: bold;
            }
            .form-label, .form-check-label {
                color: white;
                font-size: 16px;
            }
            .form-control, .form-select {
                background-color: rgba(255, 255, 255, 0.9);
                border: none;
                border-radius: 10px;
                height: 42px;
                font-size: 15px;
            }
            .btn-light {
                height: 45px;
                font-weight: bold;
                font-size: 16px;
                border-radius: 10px;
                text-decoration: none;
            }
            .register-link {
                display: block;
                margin-top: 15px;
                text-align: center;
                color: white;
            }
            
        .forgot-password {
            display: block;
            text-align: right;
            margin-bottom: 15px;
            color: white;
            text-decoration: none;
            cursor: pointer;
        }
        
        .forgot-password:hover {
            text-decoration: underline;
            color: #ddd;
        }
        
        /* Modal styles */
        .modal-content {
            background-color: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(8px);
            color: white;
            border-radius: 16px;
            border: none;
        }
        
        .modal-header {
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .modal-footer {
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .btn-close {
            filter: invert(1);
        }
        
        .password-strength {
            height: 5px;
            margin-top: 5px;
            background-color: #ddd;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s;
        }
        
        .password-requirements {
            font-size: 12px;
            margin-top: 5px;
            color: #ccc;
        }
        </style>
        <script>
        function checkPasswordStrength() {
            const password = document.getElementById('new_password').value;
            const strengthBar = document.getElementById('password-strength-bar');
            let strength = 0;
            
            // Check length
            if (password.length >= 8) strength += 1;
            // Check for numbers
            if (password.match(/\d/)) strength += 1;
            // Check for lowercase
            if (password.match(/[a-z]/)) strength += 1;
            // Check for uppercase
            if (password.match(/[A-Z]/)) strength += 1;
            // Check for special chars
            if (password.match(/[^a-zA-Z0-9]/)) strength += 1;
            
            // Update strength bar
            const width = strength * 20;
            strengthBar.style.width = width + '%';
            
            // Update color
            if (strength <= 1) {
                strengthBar.style.backgroundColor = '#ff4444';
            } else if (strength <= 3) {
                strengthBar.style.backgroundColor = '#ffbb33';
            } else {
                strengthBar.style.backgroundColor = '#00C851';
            }
        }
        </script>
    </head>
    <body>
    <!-- Navigation Bar -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#" style="color: rgba(14, 93, 230, 0.963);"><i
                        class="bi bi-car-front-fill"></i> Ride Sharer</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" href="main.html" style="color: rgba(14, 93, 230, 0.963);">Home</a>
                        <a class="nav-link" href="about.html" style="color: rgba(14, 93, 230, 0.963);">About</a>
                        <a class="nav-link" href="how_it_works.html" style="color: rgba(14, 93, 230, 0.963);">How it
                            Works</a>
                        <a class="nav-link" href="contact.html" style="color: rgba(14, 93, 230, 0.963);">Contact</a>
                    </div>

                    <div class="dropdown ms-auto me-2">
                        <button class="btn btn-outline dropdown-toggle login" type="button" id="dropdownMenuButton1"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Login
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li><a class="dropdown-item" href="admin_user.py">Admin Login</a></li>
                            <li><a class="dropdown-item" href="ridesharer_login.py">Sharer Login</a></li>
                            <li><a class="dropdown-item" href="rideseeker_loginpage.py">Seeker Login</a></li>
                        </ul>
                    </div>

                    <div class="dropdown">
                        <button class="btn btn-outline dropdown-toggle register" type="button" id="dropdownMenuButton2"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Register
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
                            <li><a class="dropdown-item" href="ridesharer.py">Ride Sharer</a></li>
                            <li><a class="dropdown-item" href="ride_seeker.py">Ride Seeker</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
        <section class="form-sec">
            <div class="form-container">
                <h2>Ride Seeker Login</h2>
                <form method="post" enctype="multipart/form-data" >
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" name="user"  id="user" placeholder="Enter username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Enter password" required>
                          <a class="forgot-password" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">Forgot Password?</a>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="main.html" class="btn btn-light">Cancel</a>
                        <button type="submit" name="login" id="login" class="btn btn-light">Login</button>
                    </div>
                    <a href="rideseeker.html" class="register-link">Create a new Register</a>
                </form>
            </div>
        </section>
        
        <!-- Forgot Password Modal -->
        <div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-labelledby="forgotPasswordModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="forgotPasswordModalLabel">Reset Password</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="post">
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="forgot_username" class="form-label">Enter your username</label>
                                <input type="text" class="form-control" id="forgot_username" name="forgot_username" required>
                            </div>
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" 
                                       placeholder="Enter new password" required onkeyup="checkPasswordStrength()">
                                <div class="password-strength">
                                    <div id="password-strength-bar" class="password-strength-bar"></div>
                                </div>
                                <div class="password-requirements">
                                    Password must be at least 8 characters long and contain at least one number and one special character.
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Password</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
           <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>RideShare</h3>
                    <p>Making travel affordable, efficient, and sustainable through shared rides.</p>
                    <div class="social-links">
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-twitter"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>

                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                       <li><a href="main.py" target="_self">Home</a></li>
                        <li><a href="about.py" target="_self">About Us</a></li>
                        <li><a href="how_it_works.py" target="_self">How It Works</a></li>
                        <li><a href="contact.py" target="_self">Contact Us</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links">
                        <li><a href="#">Daily Commute</a></li>
                        <li><a href="#">Long Distance</a></li>
                        <li><a href="#">Event Rides</a></li>
                        <li><a href="#">Airport Transfers</a></li>
                        <li><a href="#">Business Travel</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h3>Download App</h3>
                    <p>Get the best experience with our mobile app</p>
                    <a href="#" class="d-flex align-items-center mb-2 text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-apple fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">Download on the</div>
                            <div style="font-weight: 500;">App Store</div>
                        </div>
                    </a>
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none"
                        style="background: rgba(255,255,255,0.1); padding: 10px; border-radius: 8px;">
                        <i class="bi bi-google-play fs-4 me-2"></i>
                        <div>
                            <div style="font-size: 0.8rem;">GET IT ON</div>
                            <div style="font-weight: 500;">Google Play</div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="footer-bottom text-center py-3">
                <p class="mb-0">&copy; 2025 RideShare. All rights reserved.</p>
            </div>
        </div>
    </footer>
    </body>
    </html>
""")
con.close()
